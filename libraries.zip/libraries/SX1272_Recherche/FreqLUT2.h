
const uint32_t Channels_1272[] =
{
0xD7CCCC, // channel 04, central freq = 863.20MHz
0xD7E000, // channel 05, central freq = 863.50MHz
0xD7F333, // channel 06, central freq = 863.80MHz
0xD80666, // channel 07, central freq = 864.10MHz
0xD81999, // channel 08, central freq = 864.40MHz
0xD82CCC, // channel 09, central freq = 864.70MHz

0xD84CCC, // channel 10, central freq = 865.20MHz, = 865200000*RH_LORA_FCONVERT
0xD86000, // channel 11, central freq = 865.50MHz
0xD87333, // channel 12, central freq = 865.80MHz
0xD88666, // channel 13, central freq = 866.10MHz
0xD89999, // channel 14, central freq = 866.40MHz
0xD8ACCC, // channel 15, central freq = 866.70MHz
0xD8C000, // channel 16, central freq = 867.00MHz
0xD90000, // channel 17, central freq = 868.00MHz
};
