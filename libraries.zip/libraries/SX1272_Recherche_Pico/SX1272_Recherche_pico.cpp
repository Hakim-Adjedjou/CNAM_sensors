#include "SX1272_Recherche_pico.h"

#include <stdio.h>
#include <Arduino.h>
#include <stdlib.h>
#include <SPI.h>


static loRa_Para_t_SX1272  *lora_para_pt_SX1272 ; //pointeur contenant les paramètres LORA provenant de la couche application


SX1272::SX1272(uint8_t cs, uint8_t rst, uint8_t rx_sw, uint8_t tx_sw, uint8_t dio0)
{
	
	
		//Store pins numbers in array to be used in other functions 
        SX1272Pins[0] = cs;
		SX1272Pins[1] = rst;
        SX1272Pins[2] = rx_sw;
        SX1272Pins[3] = tx_sw;
        SX1272Pins[4] = dio0;
	
}


//initialize LoRa module
bool SX1272::begin(loRa_Para_t_SX1272 *lp_pt)
{
	// Assigner la valeur du pointeur lp_pt à la variable statique lora_para_pt
	lora_para_pt_SX1272 = lp_pt;
	
	//Initialize the SPI communication 
 	

	//Set chip select, rest, RX switch and Tx switch pins
	pinMode(SX1272Pins[0], OUTPUT);
	pinMode(SX1272Pins[1], OUTPUT);
	pinMode(SX1272Pins[2], OUTPUT);
	pinMode(SX1272Pins[3], OUTPUT); 
	pinMode(SX1272Pins[4], INPUT);
	
	SPI1.setRX(12);
	SPI1.setCS(9);
	SPI1.setSCK(10);
	SPI1.setTX(11);
	//SPI.begin();
	
	SPI1.begin();

	
	SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
	delay(100);
	
	
	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	//uint8_t size_temp;
	
		
	rf_freq_temp = lora_para_pt_SX1272->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt_SX1272->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt_SX1272->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt_SX1272->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt_SX1272->code_rate;  // Coding Rate CR
	//size_temp = lora_para_pt->payload_size;  // taille du payload

	//Rest LoRa chip
	digitalWrite(SX1272Pins[1], HIGH);
	delay(1);
	digitalWrite(SX1272Pins[1], LOW);
	delay(10);
	
	// Set Chip select pin high to stop communication 
	

	setLORA();
	delay(10);
	setChannel(rf_freq_temp);
	
	setPreambleLength(12);
	delay(10);
	setMode(bw_temp,sf_temp);
	delay(10);
	setHeaderON(sf_temp);
	delay(10);
	//setCRC_OFF();
	setCRC_ON();
	//setPower(power_temp);
	setPowerMax();
	
	SPI1.endTransaction();
	delay(100);
	return true;
}


//initialize LoRa module
bool SX1272::Reconfiguration(loRa_Para_t_SX1272 *lp_pt)
{
	// Assigner la valeur du pointeur lp_pt à la variable statique lora_para_pt
	lora_para_pt_SX1272 = lp_pt;
	
	//Initialize the SPI communication 
 	SPI1.begin();
	SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
	delay(100);

	
	
	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	uint8_t size_temp;
	
		
	rf_freq_temp = lora_para_pt_SX1272->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt_SX1272->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt_SX1272->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt_SX1272->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt_SX1272->code_rate;  // Coding Rate CR
	//size_temp = lora_para_pt->payload_size;  // taille du payload

	
	// Set Chip select pin high to stop communication 
	digitalWrite(SX1272Pins[0], HIGH);    
	delay(10);
	setChannel(rf_freq_temp);
	delay(10);
	setPreambleLength(12);
	delay(10);
	setMode(bw_temp,sf_temp);
	delay(10);
	SPI1.endTransaction();
	delay(10);
	return true;
}



void SX1272::setLORA()
{

    uint8_t  st0;

//#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setLORA'"));
//#endif

    // modified by C. Pham
    uint8_t retry=0;

    do {
        delay(200);
        writeRegister(REG_OP_MODE, FSK_SLEEP_MODE);    // Sleep mode (mandatory to set LoRa mode)
        writeRegister(REG_OP_MODE, LORA_SLEEP_MODE);    // LoRa sleep mode
        writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
        delay(50+retry*10);
        st0 = readRegister(REG_OP_MODE);
        Serial.println(F("..."));

        if ((retry % 2)==0) {
            if (retry==20)
                retry=0;
            else
                retry++;
        }       
        /*
        if (st0!=LORA_STANDBY_MODE) {
            pinMode(SX1272_RST,OUTPUT);
            digitalWrite(SX1272_RST,HIGH);
            delay(100);
            digitalWrite(SX1272_RST,LOW);
        }
        */

    } while (st0!=LORA_STANDBY_MODE);	// LoRa standby mode

    if( st0 == LORA_STANDBY_MODE)
    { 

//#if (SX1272_debug_mode > 1)
        Serial.println(F("## LoRa set with success ##"));
        Serial.println();
//#endif
    }
    else
    { // FSK mode

        Serial.println(F("** There has been an error while setting LoRa **"));
        Serial.println();

    }

}

void SX1272::RSSI(int16_t* RSSI)
{


#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'getRSSI'"));
#endif


            *RSSI = -OFFSET_RSSI+ readRegister(REG_RSSI_VALUE_LORA);

#if (SX1272_debug_mode > 0)
        Serial.print(F("## RSSI value is "));
        Serial.print(*RSSI, DEC);
        Serial.println(F(" ##"));
        Serial.println();
#endif
}





void SX1272::RSSIpacket(int8_t SNR, int16_t* RSSIpacket)
{	// RSSIpacket only exists in LoRa

  #if (SX1272_debug_mode > 1)
	  Serial.println();
	  Serial.println(F("Starting 'getRSSIpacket'"));
  #endif
			int16_t RSSI =0;
		  
            RSSI = readRegister(REG_PKT_RSSI_VALUE);
		  if( SNR < 0 )
		  {
			  RSSI = -OFFSET_RSSI+(double)RSSI + (double)SNR*0.25;

		  }
		  else
		  {
			   RSSI = -OFFSET_RSSI+(double)RSSI*16.0/15.0;

		  }
		  *RSSIpacket = RSSI;
	  #if (SX1272_debug_mode > 0)
		  Serial.print(F("## RSSI packet value is "));
		  Serial.print(_RSSIpacket, DEC);
  		  Serial.println(F(" ##"));
		  Serial.println();
	  #endif

  
 
}



// Get the RSSI of the last received packet
/*int16_t SX1272::PacketRssi(void)
{
	if((SNR()) >= 0)
		{
		 return -139 + ((int8_t)Read_Register(0x1A));
		}
	else
		{
		 return -139 + ((int8_t)Read_Register(0x1A)) + SNR();
		}
}
*/


//Get SNR value
/*float SX1272::SNR(void)
{
	return ((int8_t)Read_Register(0x19)) * 0.25;
}
*/

void SX1272::SNR(int8_t* SNR)
{	// getSNR exists only in LoRa mode
  //int8_t SNR
  
  uint8_t  value;

  #if (SX1272_debug_mode > 1)
	  Serial.println();
	  Serial.println(F("Starting 'getSNR'"));
  #endif

 // LoRa mode
	 
	  value = readRegister(REG_PKT_SNR_VALUE);
	  if( value & 0x80 ) // The SNR sign bit is 1
	  {
		  // Invert and divide by 4
		  value = ( ( ~value + 1 ) & 0xFF ) >> 2;
          *SNR = -value;
      }
      else
      {
		  // Divide by 4
		  *SNR = ( value & 0xFF ) >> 2;
	  }
	  #if (SX1272_debug_mode > 0)
		  Serial.print(F("## SNR value is "));
		  Serial.print(SNR, DEC);
		  Serial.println(F(" ##"));
		  Serial.println();
	  #endif
  
}



/*
 Function: Sets the bandwidth, coding rate and spreading factor of the LoRa modulation.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
   state = -1 --> Forbidden command for this protocol
 Parameters:
   mode: mode number to set the required BW, SF and CR of LoRa modem.
*/
void SX1272::setMode(uint8_t BW,uint8_t SF)
//int8_t sx1272_INSAT::setMode(uint8_t mode)
{

	int8_t state = 2;
	uint8_t  config1 = 0x00;
	uint8_t  config2 = 0x00;

	#if (SX1272_debug_mode > 1)
		Serial.println();
		Serial.println(F("Starting 'setMode'"));
	#endif


	
	// LoRa standby mode
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	
	setCR(CR_5);		// CR = 4/5
	setSF(SF,BW);		// SF = 12
	setBW(BW,SF);		// BW = 125 KHz
	//		Different way to check for each mode:
			// (config1 >> 3) ---> take out bits 7-3 from REG_MODEM_CONFIG1 (=_bandwidth & _codingRate together)
			// (config2 >> 4) ---> take out bits 7-4 from REG_MODEM_CONFIG2 (=_spreadingFactor)

			if( BW == BW_125){
									if( (config1 >> 3) == 0x01 ) // BW125
														{  config2 = readRegister(REG_MODEM_CONFIG2);
														if( (config2 >> 4) == SF )
															{
															state = 0;
														}
															else{
															
															state = -1;
																}
														}
														else{
															
															state = -1;
														}
							}
							
			if( BW == BW_250){
						 if( (config1 >> 3) == 0x09 )  //BW250
											{  config2 = readRegister(REG_MODEM_CONFIG2);
											if( (config2 >> 4) == SF )
												{
												state = 0;
											}
															else{
															
															state = -1;
																}
														}
														else{
															
															state = -1;
														}
							}

			if( BW == BW_500){
								if( (config1 >> 3) == 0x11 ) //BW500
														{  config2 = readRegister(REG_MODEM_CONFIG2);
														if( (config2 >> 4) == SF )
															{
															state = 0;
															}
															else{
															
															state = -1;
																}
														}
														else{
															
															state = -1;
														}
									}

	
	
	#if (SX1272_debug_mode > 1)
	if( state == 0 )
	{
		Serial.print(F("## Mode "));
		Serial.print(mode, DEC);
		Serial.println(F(" configured with success ##"));		
	}
	else
	{
		Serial.print(F("** There has been an error while configuring mode "));		
		Serial.print(mode, DEC);
		Serial.println(F(". **"));		
	}
	#endif
		
	
	//return state;

}

/*
 Function: Indicates if module is configured in implicit or explicit header mode.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
*/

/*
 Function: Sets the indicated CR in the module.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
   state = -1 --> Forbidden command for this protocol
 Parameters:
   cod: coding rate value to set in LoRa modem configuration.
*/
void SX1272::setCR(uint8_t cod)
{
	
  uint8_t  config1;
  #if (SX1272_debug_mode > 1)
	  Serial.println();
	  Serial.println(F("Starting 'setCR'"));
  #endif



//	  writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);		// Set Standby mode to write in registers

	  config1 = readRegister(REG_MODEM_CONFIG1);	// Save config1 to modify only the CR
	  switch(cod)
	  {
		 case CR_5: config1 = config1 & 0b11001111;	// clears bits 5 & 4 from REG_MODEM_CONFIG1
					config1 = config1 | 0b00001000;	// sets bit 3 from REG_MODEM_CONFIG1
					break;
		 case CR_6: config1 = config1 & 0b11010111;	// clears bits 5 & 3 from REG_MODEM_CONFIG1
					config1 = config1 | 0b00010000;	// sets bit 4 from REG_MODEM_CONFIG1
					break;
		 case CR_7: config1 = config1 & 0b11011111;	// clears bit 5 from REG_MODEM_CONFIG1
					config1 = config1 | 0b00011000;	// sets bits 4 & 3 from REG_MODEM_CONFIG1
					break;
		 case CR_8: config1 = config1 & 0b11100111;	// clears bits 4 & 3 from REG_MODEM_CONFIG1
					config1 = config1 | 0b00100000;	// sets bit 5 from REG_MODEM_CONFIG1
					break;
	  }
	  writeRegister(REG_MODEM_CONFIG1, config1);		// Update config1


}

/*
 Function: Sets the indicated SF in the module.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
 Parameters:
   spr: spreading factor value to set in LoRa modem configuration.
*/
void SX1272::setSF(uint8_t SF , uint8_t BW)
{
    uint8_t  st0;
    int8_t state = 2;
    uint8_t  config1=0;
    uint8_t  config2=0;
    uint8_t  config3=0;
    
#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setSF'"));
#endif

	// modified by C. Pham
//	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	// LoRa standby mode
	config1 = (readRegister(REG_MODEM_CONFIG1));	// Save config1 to modify only the LowDataRateOptimize
	config2 = (readRegister(REG_MODEM_CONFIG2));	// Save config2 to modify SF value (bits 7-4)
	
	//getBW();
	
	boolean isLowDROp=false;
	
	//Mandatory with SF_11/12 and BW_125 as symbol duration > 16ms) 
	if ( (SF==SF_11 || SF==SF_12) && BW == BW_125 )
		isLowDROp=true;
	
	//Mandatory with SF_12 and BW_250 as symbol duration > 16ms)	
	if ( SF==SF_12 && BW == BW_250 )
		isLowDROp=true;
		
	switch(SF)
	{
	case SF_6: 	config2 = config2 & 0b01101111;	// clears bits 7 & 4 from REG_MODEM_CONFIG2
		config2 = config2 | 0b01100000;	// sets bits 6 & 5 from REG_MODEM_CONFIG2
		break;
	case SF_7: 	config2 = config2 & 0b01111111;	// clears bits 7 from REG_MODEM_CONFIG2
		config2 = config2 | 0b01110000;	// sets bits 6, 5 & 4
		break;
	case SF_8: 	config2 = config2 & 0b10001111;	// clears bits 6, 5 & 4 from REG_MODEM_CONFIG2
		config2 = config2 | 0b10000000;	// sets bit 7 from REG_MODEM_CONFIG2
		break;
	case SF_9: 	config2 = config2 & 0b10011111;	// clears bits 6, 5 & 4 from REG_MODEM_CONFIG2
		config2 = config2 | 0b10010000;	// sets bits 7 & 4 from REG_MODEM_CONFIG2
		break;
	case SF_10:	config2 = config2 & 0b10101111;	// clears bits 6 & 4 from REG_MODEM_CONFIG2
		config2 = config2 | 0b10100000;	// sets bits 7 & 5 from REG_MODEM_CONFIG2
		break;
	case SF_11:	config2 = config2 & 0b10111111;	// clears bit 6 from REG_MODEM_CONFIG2
		config2 = config2 | 0b10110000;	// sets bits 7, 5 & 4 from REG_MODEM_CONFIG2
		break;
	case SF_12: config2 = config2 & 0b11001111;	// clears bits 5 & 4 from REG_MODEM_CONFIG2
		config2 = config2 | 0b11000000;	// sets bits 7 & 6 from REG_MODEM_CONFIG2
		break;
	}
	
	// added by C. Pham
	if (isLowDROp)
	{ // LowDataRateOptimize 
			config1 = config1 | 0b00000001;

	}
	else
	{ // No LowDataRateOptimize  
			config1 = config1 & 0b11111110;

	}

	// added by C. Pham

		// set the AgcAutoOn in bit 2 of REG_MODEM_CONFIG2
		// modified by C. Pham
		config2 = config2 | 0b00000100;
		
		// Update config1 now for SX1272Chip
		writeRegister(REG_MODEM_CONFIG1, config1);		

	// here we write the new SF
	writeRegister(REG_MODEM_CONFIG2, config2);		// Update config2

	// Check if it is neccesary to set special settings for SF=6
	if( SF == SF_6 )
	{
		// Mandatory headerOFF with SF = 6 (Implicit mode)
		setHeaderOFF();

		// Set the bit field DetectionOptimize of
		// register RegLoRaDetectOptimize to value "0b101".
		writeRegister(REG_DETECT_OPTIMIZE, 0x05);

		// Write 0x0C in the register RegDetectionThreshold.
		writeRegister(REG_DETECTION_THRESHOLD, 0x0C);
	}
	else
	{
		// added by C. Pham
		setHeaderON(SF);

		// LoRa detection Optimize: 0x03 --> SF7 to SF12
		writeRegister(REG_DETECT_OPTIMIZE, 0x03);

		// LoRa detection threshold: 0x0A --> SF7 to SF12
		writeRegister(REG_DETECTION_THRESHOLD, 0x0A);
	}
	
}

/*
 Function: Sets the indicated BW in the module.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
 Parameters:
   band: bandwith value to set in LoRa modem configuration.
*/
void SX1272::setBW(uint16_t band , uint8_t SF)
{
    uint8_t  st0;
    int8_t state = 2;
    uint8_t  config1;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setBW'"));
#endif

    
    //writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	// LoRa standby mode
    config1 = (readRegister(REG_MODEM_CONFIG1));	// Save config1 to modify only the BW
    
    //getSF();

    // added by C. Pham for SX1276
    
	switch(band)
	{
	case BW_125:  config1 = config1 & 0b00111110;	// clears bits 7 & 6 and 0 (no LowDataRateOptimize) from REG_MODEM_CONFIG1
		if( SF == 11 || SF == 12 )
		{ // LowDataRateOptimize (Mandatory with BW_125 if SF_11/12)
			config1 = config1 | 0b00000001;
		}
		break;
	case BW_250:  config1 = config1 & 0b01111110;	// clears bit 7 and 0 (no LowDataRateOptimize) from REG_MODEM_CONFIG1
		config1 = config1 | 0b01000000;	// sets bit 6 from REG_MODEM_CONFIG1
		if( SF == 12 )
		{ // LowDataRateOptimize (Mandatory with BW_250 if SF_12)
			config1 = config1 | 0b00000001;
		}            
		break;
	case BW_500:  config1 = config1 & 0b10111110;	//clears bit 6 and 0 (no LowDataRateOptimize) from REG_MODEM_CONFIG1
		config1 = config1 | 0b10000000;	//sets bit 7 from REG_MODEM_CONFIG1
		break;
	}
    

    // end

    writeRegister(REG_MODEM_CONFIG1,config1);		// Update config1

    delay(100);    

#if (SX1272_debug_mode > 1)
        Serial.print(F("## Bandwidth "));
        Serial.print(band, HEX);
        Serial.println(F(" has been successfully set ##"));
        Serial.println();
#endif
 
    delay(100);
    //return state;
}


void SX1272::AfficheBW(uint8_t BW){
	
	 switch(BW){
        case 0:
        Serial.println("125 kHz");
        break;
        case 1:
        Serial.println("250 kHz");
        break;
        case 2:
        Serial.println("500 kHz");
        break; 
        }
}


/*
 Function: Writes on the indicated register.
 Returns: Nothing
 Parameters:
   address: address register to write in
   data : value to write in the register
*/
void SX1272::writeRegister(uint8_t  address, uint8_t  data)
{
    digitalWrite(SX1272Pins[0],LOW);
    bitSet(address, 7);			// Bit 7 set to read from registers
    SPI1.transfer(address);
    SPI1.transfer(data);
    digitalWrite(SX1272Pins[0],HIGH);

#if (SX1272_debug_mode > 1)
    Serial.print(F("## Writing:  ##\t"));
    Serial.print(F("Register "));
    bitClear(address, 7);
    Serial.print(address, HEX);
    Serial.print(F(":  "));
    Serial.print(data, HEX);
    Serial.println();
#endif

}




uint8_t  SX1272::readRegister(uint8_t  address)
{
    uint8_t  value = 0x00;

    digitalWrite(SX1272Pins[0],LOW);
    bitClear(address, 7);		// Bit 7 cleared to write in registers
    SPI1.transfer(address);
    value = SPI1.transfer(0x00);
    digitalWrite(SX1272Pins[0],HIGH);

#if (SX1272_debug_mode > 1)
    Serial.print(F("## Reading:  ##\t"));
    Serial.print(F("Register "));
    Serial.print(address, HEX);
    Serial.print(F(":  "));
    Serial.print(value, HEX);
    Serial.println();
#endif

    return value;
}




void SX1272::setChannel(uint32_t ch)
{
    uint8_t  st0;
    int8_t state = 2;
    uint8_t  freq3;
    uint8_t  freq2;
    uint8_t  freq1;
    uint32_t freq;
	//Serial.println("FREQUENCE 4:");
	//Serial.println(ch);	
#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setChannel'"));
#endif

    freq3 = ((ch >> 16) & 0xFF);     // frequency channel MSB
    freq2 = ((ch >> 8) & 0xFF);      // frequency channel MIB
    freq1 = (ch & 0xFF);             // frequency channel LSB

    writeRegister(REG_FRF_MSB, freq3);
    writeRegister(REG_FRF_MID, freq2);
    writeRegister(REG_FRF_LSB, freq1);

    delay(5);

    // storing MSB in freq channel value
    freq3 = (readRegister(REG_FRF_MSB)) >> 8;
    freq = (freq3 << 16) & 0xFFFFFF;

    // storing MID in freq channel value
    freq2 = (readRegister(REG_FRF_MID));
    freq = (freq << 8) + (freq2 & 0xFF);

    // storing LSB in freq channel value
    freq = freq + (readRegister(REG_FRF_LSB) & 0xFF);

    if (freq == ch)
    {
        state = 0;
       
#if (SX1272_debug_mode > 1)
        Serial.print(F("## Frequency channel "));
        Serial.print(ch, HEX);
        Serial.println(F(" has been successfully set ##"));
        Serial.println();
#endif
    }

    delay(5);
    //return state;
}




/*
 Function: Sets the module in explicit header mode (header is sent).
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
   state = -1 --> Forbidden command for this protocol
*/

void SX1272::setHeaderON(uint8_t SF)
{
    int8_t state = 2;
    uint8_t  config1;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setHeaderON'"));
#endif

        config1 = readRegister(REG_MODEM_CONFIG1);	// Save config1 to modify only the header bit
        if( SF== 6 )
        {
            state = -1;		// Mandatory headerOFF with SF = 6
#if (SX1272_debug_mode > 1)
            Serial.println(F("## Mandatory implicit header mode with spreading factor = 6 ##"));
#endif
        }
        else
        {

        config1 = config1 & 0b11111011;		// clears bit 2 from config1 = headerON
        writeRegister(REG_MODEM_CONFIG1,config1);	// Update config1
        }

        // added by C. Pham
        uint8_t theHeaderBit;

        theHeaderBit=2;


        if( SF != 6 )
        { // checking headerON taking out bit 2 from REG_MODEM_CONFIG1
            config1 = readRegister(REG_MODEM_CONFIG1);
            // modified by C. Pham
            if( bitRead(config1, theHeaderBit) == HEADER_ON )
            {
                state = 0;
                
#if (SX1272_debug_mode > 1)
                Serial.println(F("## Header has been activated ##"));
                Serial.println();
#endif
            }
            else
            {
                state = 1;
            }
        }
    
	//return state;
}

/*
 Function: Sets the module in implicit header mode (header is not sent).
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
   state = -1 --> Forbidden command for this protocol
*/

void SX1272::setHeaderOFF()
{
    uint8_t state = 2;
    uint8_t  config1;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setHeaderOFF'"));
#endif

        config1 = readRegister(REG_MODEM_CONFIG1);	// Save config1 to modify only the header bit


        config1 = config1 | 0b00000100;			// sets bit 2 from REG_MODEM_CONFIG1 = headerOFF
            

        writeRegister(REG_MODEM_CONFIG1,config1);		// Update config1

        config1 = readRegister(REG_MODEM_CONFIG1);

        // added by C. Pham
        uint8_t theHeaderBit;


        theHeaderBit=2;


        if( bitRead(config1, theHeaderBit) == HEADER_OFF )
        { // checking headerOFF taking out bit 2 from REG_MODEM_CONFIG1
            state = 0;
            

#if (SX1272_debug_mode > 1)
            Serial.println(F("## Header has been desactivated ##"));
            Serial.println();
#endif
        }
        else
        {
            state = 1;
#if (SX1272_debug_mode > 1)
            Serial.println(F("** Header hasn't been desactivated ##"));
            Serial.println();
#endif
        }
  
    //return state;
}

/*
 Function: Indicates if module is configured with or without checking CRC.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
*/



void SX1272::setPreambleLength(uint16_t l)
{
    uint8_t  st0;
    uint8_t p_length;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setPreambleLength'"));
#endif

	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);    // Set Standby mode to write in registers
	p_length = ((l >> 8) & 0x0FF);
	// Storing MSB preamble length in LoRa mode
	writeRegister(REG_PREAMBLE_MSB_LORA, p_length);
	p_length = (l & 0x0FF);
	// Storing LSB preamble length in LoRa mode
	writeRegister(REG_PREAMBLE_LSB_LORA, p_length);

#if (SX1272_debug_mode > 1)
    Serial.print(F("## Preamble length "));
    Serial.print(l, HEX);
    Serial.println(F(" has been successfully set ##"));
    Serial.println();
#endif

    delay(100);
    //return state;
}

/*
 Function: Gets the payload length from the module.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
*/

uint8_t SX1272::getPayloadLength()
{

    uint8_t state = 2;
	uint8_t payloadlength = 0;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'getPayloadLength'"));
#endif

        // Saving payload length in LoRa mode
        payloadlength = readRegister(REG_PAYLOAD_LENGTH_LORA);
        state = 1;

#if (SX1272_debug_mode > 1)
    Serial.print(F("## Payload length configured is "));
    Serial.print(payloadlength, HEX);
    Serial.println(F(" ##"));
    Serial.println();
#endif

 
    return payloadlength;
}

void SX1272::GetPacketStatus(int8_t* SNR_R, int16_t* RSSIpacket_R){
	
	SNR(SNR_R);
	RSSIpacket(*SNR_R, RSSIpacket_R);
	
}

/*
 Function: Sets the signal power indicated as input to the module.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
   state = -1 --> Forbidden command for this protocol
 Parameters:
   pow: power option to set in configuration. The input value range is from 
   0 to 14 dBm.
*/
void SX1272::setPower(uint8_t pow)
{
  uint8_t  st0;
  uint8_t power;
  int8_t state = 2;
  uint8_t  value = 0x00;

  #if (SX1272_debug_mode > 1)
	  Serial.println();
	  Serial.println(F("Starting 'setPower'"));
  #endif

  
  if(pow < 0)
  {
	  power = 0;
  }
    else if(pow > 20)
  {
	  power = 20;
  }
  else
  {
	  power = pow;
  }

  writeRegister(REG_PA_CONFIG, power);	// Setting output power value
  value = readRegister(REG_PA_CONFIG);

  if( value == power )
  {
	  state = 0;
	  #if (SX1272_debug_mode > 1)
		  Serial.println(F("## Output power has been successfully set ##"));
		  Serial.println();
	  #endif
	  //return state;
  }
  
}

void SX1272::setPowerMax()
{
 
  //uint8_t power;
   uint8_t power = 0x00;
  int8_t state = 2;
  uint8_t value = 0x00;

  //#if (SX1272_debug_mode > 1)
	  Serial.println();
	  Serial.println(F("Starting 'setPowerMax'"));
  //#endif

	power=0x0F;
	power = power | 0b10000000;
 
	  // and then set the high output power config with register REG_PA_DAC
	writeRegister(REG_PA_DAC, 0x87);
	// set RegOcp for OcpOn and OcpTrim
	// 150mA
	setMaxCurrent(0x12);

	writeRegister(REG_PA_CONFIG, power);	// Setting output power value
    value = readRegister(REG_PA_CONFIG);
	
  if( value == power )
  {
	  state = 0;
	  //#if (SX1272_debug_mode > 1)
		  Serial.println(F("## Output power has been successfully set ##"));
		  Serial.println();
	  //#endif
	  //return state;
  }

  
}


int8_t SX1272::setMaxCurrent(uint8_t rate)
{
    int8_t state = 2;
   // uint8_t st0;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setMaxCurrent'"));
#endif

    // Maximum rate value = 0x1B, because maximum current supply = 240 mA
    if (rate > 0x1B)
    {
        state = -1;
#if (SX1272_debug_mode > 1)
        Serial.print(F("** Maximum current supply is 240 mA, "));
        Serial.println(F("so maximum parameter value must be 27 (DEC) or 0x1B (HEX) **"));
        Serial.println();
#endif
    }
    else
    {
        // Enable Over Current Protection
        rate |= 0b00100000;

        state = 1;
        //st0 = readRegister(REG_OP_MODE);	// Save the previous status

         // LoRa mode
            writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	// Set LoRa Standby mode to write in registers

		
        writeRegister(REG_OCP, rate);		// Modifying maximum current supply
       // writeRegister(REG_OP_MODE, st0);		// Getting back to previous status
        state = 0;
    }
    return state;
}

/*
 * Function: Clears the interruption flags
 * 
 * LoRa Configuration registers are accessed through the SPI interface. 
 * Registers are readable in all device mode including Sleep. However, they 
 * should be written only in Sleep and Stand-by modes.
 * 
 * Returns: Nothing
*/
void SX1272::clearFlags()
{
		/// LoRa mode
		// Stdby mode to write in registers		
		writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	
		// LoRa mode flags register
		writeRegister(REG_IRQ_FLAGS, 0xFF);	
		
		#if (SX1272_debug_mode > 1)
			Serial.println(F("## LoRa flags cleared ##"));
		#endif
}







//send package
void SX1272::SendPackage(char *Package, uint8_t packageLength)
{
	Serial.println("en cours d envoie");
  uint16_t i;
  uint8_t  Value;
  SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  delay(1);
  
  	//Switch LoRa to standby mode
  	//Mode(STANDBY);
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);	
  	
  	//Set payload length
    writeRegister(REG_PAYLOAD_LENGTH_LORA, packageLength);

  	//Load FIFO tx pointer
  	Value = readRegister(REG_FIFO_TX_BASE_ADDR);	//get FIFO address pointer value
  	writeRegister(REG_FIFO_ADDR_PTR, Value);	//set SPI interface address pointer in FIFO data buffer.

  	

	writeRegister(REG_PA_RAMP, 0x08);
  	//IRQ mask
  	writeRegister(REG_IRQ_FLAGS_MASK, 0x87);

  	//IRQ flag
  	writeRegister(REG_IRQ_FLAGS, 0xFF);

  	//Write payload in to the FIFO
  	for (i = 0; i < packageLength; i++)
  	{
   	 writeRegister(0x80, *Package);
   	 //delay(100);
   	 Package++;
  	}

	
	//Transmit Mode
  	digitalWrite(SX1272Pins[3], HIGH); //TX_SW = 1;
  	digitalWrite(SX1272Pins[2], LOW);  //RX_SW = 0;
  	//Close TX LoRa
  	writeRegister(REG_OP_MODE, 0x82); //FREQUENCY SYNTHESIS TX
  	writeRegister(0x01, LORA_TX_MODE);

  	//Wait until tx done
  	do
  	{
   		Value = readRegister(REG_IRQ_FLAGS);

    	Value = Value & 0x08;
		delay(1);
  	} while (Value == 0);

  	delay(1);
	Serial.println("fin d envoie");
	clearFlags();
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
  	digitalWrite(SX1272Pins[3], LOW);  //TX_SW = 0;
  	digitalWrite(SX1272Pins[2], LOW); //RX_SW = 0;
	digitalWrite(SX1272Pins[0], HIGH);
	
	/*//Check for interrupt
	if(!interrupt)
	{
  	//stop sending and receiving 
  	digitalWrite(TX_SW, LOW);  //TX_SW = 0;
  	digitalWrite(RX_SW, LOW); //RX_SW = 0;
	}
	else 
	{
	 // Receive Mode
  	 digitalWrite(LoRaPins[3], LOW);	//TX_SW = 0;
  	 digitalWrite(LoRaPins[2], HIGH);	//RX_SW = 1;
	}
*/
	SPI1.endTransaction();
}



//Receive package
uint8_t SX1272::ReceivePackage(char *Package, uint8_t packageLength)
{
	SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  delay(1);
boolean CRC = false;
uint8_t  value ;
  uint16_t i;
  uint8_t  LoRa_Interrupt;
  uint8_t  PackageLocation;
  static uint32_t Debut_Attente_Reponse =0;
	
  //uint8_t packageLength;
  	digitalWrite(SX1272Pins[0], HIGH);
	
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	 //IRQ mask
  	writeRegister(REG_IRQ_FLAGS_MASK, 0x87);
	//IRQ flag
  	writeRegister(REG_IRQ_FLAGS, 0xFF);
	
	
	
	writeRegister(REG_LNA, LNA_MAX_GAIN);
  	writeRegister(REG_OP_MODE, 0x84);  //FREQUENCY SYNTHESIS RX
	writeRegister(REG_FIFO_ADDR_PTR, 0x00); 
	// Setting address pointer in FIFO data buffer
	writeRegister(REG_FIFO_RX_BYTE_ADDR, 0x00);
	
	value = readRegister(REG_IRQ_FLAGS);
	writeRegister(REG_OP_MODE, LORA_RX_MODE); 
	  
	  digitalWrite(SX1272Pins[3], LOW);		//TX_SW = 0;
  	  digitalWrite(SX1272Pins[2], HIGH);	   //RX_SW = 1;

    while ((digitalRead(SX1272Pins[4]) == 0) && ((bitRead(value, 6) == 0)))
    {
		
      delay(1);
	  value = readRegister(REG_IRQ_FLAGS);
    }

	Debut_Attente_Reponse = millis();
	value = readRegister(REG_IRQ_FLAGS);
	        if ((bitRead(value, 6) == 1)) {
#if (SX1272_debug_mode > 0)
            Serial.println(F("## Packet received in LoRa mode ##"));
#endif

            //CrcOnPayload?
            if (bitRead(readRegister(REG_HOP_CHANNEL),6)) {

                if ( (bitRead(value, 5) == 0) ) {
  
                    Serial.println(F("** The CRC is correct **"));
					CRC = true;

                }

            }
            else {
                  CRC = true;

					#if (SX1272_debug_mode > 0)
                  Serial.println(F("## Packet supposed to be correct as CrcOnPayload is off at transmitter ##"));
					#endif
             }
        }
	
	if(CRC){
			//packageLength = getPayloadLength();
			//Get interrupt register
			//LoRa_Interrupt = readRegister(REG_IRQ_FLAGS);
		  
			//Clear interrupt register
			//writeRegister(REG_IRQ_FLAGS, 0x60);
			
			//clearFlags();

			//Get package location
			PackageLocation = readRegister(REG_FIFO_RX_CURRENT_ADDR);

			//Set SPI pointer to PackageLocation
			writeRegister(REG_FIFO_ADDR_PTR, PackageLocation);

					//Get message
					for (i = 0; i < packageLength; i++)
					{
						*Package = readRegister(REG_FIFO);
						Package++;
					}

	}
	clearFlags();
  	//stop sending and receiving 
  	digitalWrite(SX1272Pins[3], LOW);  //TX_SW = 0;
  	digitalWrite(SX1272Pins[2], LOW); //RX_SW = 0;
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	digitalWrite(SX1272Pins[0], HIGH);
	
	SPI1.endTransaction();
   return 1;
}



uint8_t SX1272::ReceivePackageGateWay(char *Package, uint8_t packageLength,uint32_t Delai_Attente_Reponse)
{
	SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  delay(1);
boolean CRC = false;
uint8_t  value ;
  uint16_t i;
  uint8_t  LoRa_Interrupt;
  uint8_t  PackageLocation;
  //uint8_t packageLength;
  static uint32_t Debut_Attente_Reponse =0;
	Debut_Attente_Reponse = millis();
  
  
  
  	digitalWrite(SX1272Pins[0], HIGH);
	
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	 //IRQ mask
  	writeRegister(REG_IRQ_FLAGS_MASK, 0x87);
	//IRQ flag
  	writeRegister(REG_IRQ_FLAGS, 0xFF);
	
	
	
	writeRegister(REG_LNA, LNA_MAX_GAIN);
  	writeRegister(REG_OP_MODE, 0x84);  //FREQUENCY SYNTHESIS RX
	writeRegister(REG_FIFO_ADDR_PTR, 0x00); 
	// Setting address pointer in FIFO data buffer
	writeRegister(REG_FIFO_RX_BYTE_ADDR, 0x00);
	
	value = readRegister(REG_IRQ_FLAGS);
	writeRegister(REG_OP_MODE, LORA_RX_MODE); 
	  
	  digitalWrite(SX1272Pins[3], LOW);		//TX_SW = 0;
  	  digitalWrite(SX1272Pins[2], HIGH);	   //RX_SW = 1;

   
    //while ((digitalRead(SX1272Pins[4]) == 0) && ((bitRead(value, 6) == 0)) && (millis()-Debut_Attente_Reponse<=Delai_Attente_Reponse))
	    while ((digitalRead(SX1272Pins[4]) == 0) && ((bitRead(value, 6) == 0)))	
    {
		
      delay(1);
	  value = readRegister(REG_IRQ_FLAGS);
							if((millis()-Debut_Attente_Reponse>Delai_Attente_Reponse)){
							
							return 0;
																		}
    }

	/*if((millis()-Debut_Attente_Reponse>Delai_Attente_Reponse)){
		
		return 0;
	}
	*/
	value = readRegister(REG_IRQ_FLAGS);
	        if ((bitRead(value, 6) == 1)) {
#if (SX1272_debug_mode > 0)
            Serial.println(F("## Packet received in LoRa mode ##"));
#endif

            //CrcOnPayload?
            if (bitRead(readRegister(REG_HOP_CHANNEL),6)) {

                if ( (bitRead(value, 5) == 0) ) {
  
                    Serial.println(F("** The CRC is correct **"));
					CRC = true;

                }
				else{
					
					Serial.println(F("** The CRC is NOT correct **"));
					return 0;
				}

            }
            else {
                  
				  CRC = true;
					//#if (SX1272_debug_mode > 0)
                  Serial.println(F("## Packet supposed to be correct as CrcOnPayload is off at transmitter ##"));
					//#endif
             }
        }
	
	if(CRC){
			//packageLength = getPayloadLength();
			//Get interrupt register
			//LoRa_Interrupt = readRegister(REG_IRQ_FLAGS);
		  
			//Clear interrupt register
			//writeRegister(REG_IRQ_FLAGS, 0x60);
			
			//clearFlags();

			//Get package location
			PackageLocation = readRegister(REG_FIFO_RX_CURRENT_ADDR);

			//Set SPI pointer to PackageLocation
			writeRegister(REG_FIFO_ADDR_PTR, PackageLocation);

					//Get message
					for (i = 0; i < packageLength; i++)
					{
						*Package = readRegister(REG_FIFO);
						 //Serial.println(*Package);
						Package++;
					}

	}
	clearFlags();
  	//stop sending and receiving 
  	digitalWrite(SX1272Pins[3], LOW);  //TX_SW = 0;
  	digitalWrite(SX1272Pins[2], LOW); //RX_SW = 0;
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	digitalWrite(SX1272Pins[0], HIGH);
	
	SPI1.endTransaction();
   return 1;
}


uint8_t SX1272::ReceivePackageGateWay(char *Package, uint8_t packageLength)
{
	SPI1.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  delay(1);
boolean CRC = false;
uint8_t  value ;
  uint16_t i;
  uint8_t  LoRa_Interrupt;
  uint8_t  PackageLocation;
  //uint8_t packageLength;
  static uint32_t Debut_Attente_Reponse =0;

  
  
  
  	digitalWrite(SX1272Pins[0], HIGH);
	
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	 //IRQ mask
  	writeRegister(REG_IRQ_FLAGS_MASK, 0x87);
	//IRQ flag
  	writeRegister(REG_IRQ_FLAGS, 0xFF);
	
	
	
	writeRegister(REG_LNA, LNA_MAX_GAIN);
  	writeRegister(REG_OP_MODE, 0x84);  //FREQUENCY SYNTHESIS RX
	writeRegister(REG_FIFO_ADDR_PTR, 0x00); 
	// Setting address pointer in FIFO data buffer
	writeRegister(REG_FIFO_RX_BYTE_ADDR, 0x00);
	
	value = readRegister(REG_IRQ_FLAGS);
	writeRegister(REG_OP_MODE, LORA_RX_MODE); 
	  
	  digitalWrite(SX1272Pins[3], LOW);		//TX_SW = 0;
  	  digitalWrite(SX1272Pins[2], HIGH);	   //RX_SW = 1;

   
    //while ((digitalRead(SX1272Pins[4]) == 0) && ((bitRead(value, 6) == 0)) && (millis()-Debut_Attente_Reponse<=Delai_Attente_Reponse))
	    while ((digitalRead(SX1272Pins[4]) == 0) && ((bitRead(value, 6) == 0)))	
    {
		
      delay(1);
	  value = readRegister(REG_IRQ_FLAGS);
						
    }
			Debut_Attente_Reponse = millis();
	/*if((millis()-Debut_Attente_Reponse>Delai_Attente_Reponse)){
		
		return 0;
	}
	*/
	value = readRegister(REG_IRQ_FLAGS);
	        if ((bitRead(value, 6) == 1)) {
#if (SX1272_debug_mode > 0)
            Serial.println(F("## Packet received in LoRa mode ##"));
#endif

            //CrcOnPayload?
            if (bitRead(readRegister(REG_HOP_CHANNEL),6)) {

                if ( (bitRead(value, 5) == 0) ) {
  
                    Serial.println(F("** The CRC is correct **"));
					CRC = true;

                }
				else{
					
					Serial.println(F("** The CRC is NOT correct **"));
					return 0;
				}

            }
            else {
                  
				  CRC = true;
					//#if (SX1272_debug_mode > 0)
                  Serial.println(F("## Packet supposed to be correct as CrcOnPayload is off at transmitter ##"));
					//#endif
             }
        }
	
	if(CRC){
			//packageLength = getPayloadLength();
			//Get interrupt register
			//LoRa_Interrupt = readRegister(REG_IRQ_FLAGS);
		  
			//Clear interrupt register
			//writeRegister(REG_IRQ_FLAGS, 0x60);
			
			//clearFlags();

			//Get package location
			PackageLocation = readRegister(REG_FIFO_RX_CURRENT_ADDR);

			//Set SPI pointer to PackageLocation
			writeRegister(REG_FIFO_ADDR_PTR, PackageLocation);

					//Get message
					for (i = 0; i < packageLength; i++)
					{
						*Package = readRegister(REG_FIFO);
						 //Serial.println(*Package);
						Package++;
					}

	}
	clearFlags();
  	//stop sending and receiving 
  	digitalWrite(SX1272Pins[3], LOW);  //TX_SW = 0;
  	digitalWrite(SX1272Pins[2], LOW); //RX_SW = 0;
	writeRegister(REG_OP_MODE, LORA_STANDBY_MODE);
	digitalWrite(SX1272Pins[0], HIGH);
	SPI1.endTransaction();
   return 1;
}



//handling String
uint8_t SX1272::Send(const String &s)
{
	SendPackage((char *)s.c_str(), (uint8_t) s.length());   
	return 1;
}



//handling constant char
uint8_t SX1272::Send(const char package[])
{
	SendPackage((char *) package, strlen(package));
	return 1;
}


//handling char
uint8_t SX1272::Send(char package)
{
	uint8_t len = sizeof(package);
	SendPackage( &package, len);
	return 1;
}

//handling unsigned char
uint8_t SX1272::Send(unsigned char package)
{
	uint8_t len = sizeof(package);
	SendPackage((char*) &package, len);
	return 1;
}





//handling int
uint8_t SX1272::Send(int package)
{
	char buffer[10];
	itoa(package, buffer, 10);
	SendPackage(buffer, 10);
	return 1;
}


//Handling unsigned int
uint8_t SX1272::Send(unsigned int package)
{
	uint8_t len = sizeof(package);
	char buffer[10];
	utoa(package, buffer, 10);
	SendPackage(buffer, 10);
	return 1;

}



//Handling long
uint8_t SX1272::Send(long l)
{
	long_conv.union_long = l;
	SendPackage(long_conv.union_char, 4);
	return 1;
}



//Handling unsigned long
uint8_t SX1272::Send(unsigned long l)
{
	Ulong_conv.union_Ulong = l;
	SendPackage(Ulong_conv.union_char, 4);
	return 1;
}



//Handling double
uint8_t SX1272::Send(double package, uint8_t digit)
{
	uint8_t len = sizeof(package);

	char convertedChar[20];

	dtostrf(package, 4, digit, convertedChar);

	SendPackage(convertedChar, 20);
	return 1;
	
}



//Habdling received data


//Handling received int
int SX1272::ReceiveInt(void)
{
	char receivedChar[10];
	//Get received data in char type
	ReceivePackage(receivedChar,10); 
	
	//convert char data to int
	return atoi(receivedChar);
}


//Handling received unsigned int
unsigned int SX1272::ReceiveUint(void)
{
	char receivedUint[10];
	//Get received data in char type
	ReceivePackage(receivedUint,10);
	
	//convert char data to unsigned int and return it 
	return strtoul(receivedUint,NULL,10);
}


//Handling received long
long SX1272::ReceiveLong(void)
{
	char receivedLong[4];
	//Get received data in char type
	ReceivePackage(receivedLong,4);

	long_conv.union_char[0] = receivedLong[0];
	long_conv.union_char[1] = receivedLong[1];
	long_conv.union_char[2] = receivedLong[2];
	long_conv.union_char[3] = receivedLong[3];

	return long_conv.union_long;
}



//Handling received unsigned long
unsigned long SX1272::ReceiveUlong(void)
{
	char receivedUlong[4];
	//Get received data in char type
	ReceivePackage(receivedUlong,4);

	Ulong_conv.union_char[0] = receivedUlong[0];
	Ulong_conv.union_char[1] = receivedUlong[1];
	Ulong_conv.union_char[2] = receivedUlong[2];
	Ulong_conv.union_char[3] = receivedUlong[3];

	return Ulong_conv.union_Ulong;
}


//Handling received double
double SX1272::ReceiveDouble(void)
{
	char receivedDouble[20];
	//Get received data in char type
	ReceivePackage(receivedDouble,20);
	
	return atof(receivedDouble);
}



//Receive char
char SX1272::ReceiveChar(void)
{
	char receivedchar[1];

	ReceivePackage(receivedchar,1);
	
	return receivedchar[0];
}



//Receive unsigned char
unsigned char SX1272::ReceiveUchar(void)
{
	char receivedUchar[1];

	ReceivePackage(receivedUchar,1);
	
	return (unsigned char) receivedUchar[0];
}



void	 SX1272::setCRC_ON()
{
    uint8_t state = 2;
    uint8_t  config1;

#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setCRC_ON'"));
#endif

// LORA mode

        // added by C. Pham
        uint8_t theRegister;
        uint8_t theCrcBit;


		theRegister=REG_MODEM_CONFIG1;
		theCrcBit=1;


        config1 = readRegister(theRegister);	// Save config1 to modify only the CRC bit

            config1 = config1 | 0b00000010;				// sets bit 1 from REG_MODEM_CONFIG1 = CRC_ON


        writeRegister(theRegister,config1);

        state = 1;

        config1 = readRegister(theRegister);

        if( bitRead(config1, theCrcBit) == CRC_ON )
        { // take out bit 1 from REG_MODEM_CONFIG1 indicates RxPayloadCrcOn
            state = 0;

//#if (SX1272_debug_mode > 1)
            Serial.println(F("## CRC has been activated ##"));
            Serial.println();
//#endif
        }


    if( state != 0 )
    {
        state = 1;
#if (SX1272_debug_mode > 1)
        Serial.println(F("** There has been an error while setting CRC ON **"));
        Serial.println();
#endif
    }
    //return state;
}

/*
 Function: Sets the module with CRC off.
 Returns: Integer that determines if there has been any error
   state = 2  --> The command has not been executed
   state = 1  --> There has been an error while executing the command
   state = 0  --> The command has been executed with no errors
*/
void SX1272::setCRC_OFF()
{
    int8_t state = 2;
    uint8_t  config1;

//#if (SX1272_debug_mode > 1)
    Serial.println();
    Serial.println(F("Starting 'setCRC_OFF'"));
//#endif

        // added by C. Pham
        uint8_t theRegister;
        uint8_t theCrcBit;

            theRegister=REG_MODEM_CONFIG1;
            theCrcBit=1;



        config1 = readRegister(theRegister);	// Save config1 to modify only the CRC bit

        config1 = config1 & 0b11111101;				// clears bit 1 from config1 = CRC_OFF


        writeRegister(theRegister,config1);

        config1 = readRegister(theRegister);
        if( (bitRead(config1, theCrcBit)) == CRC_OFF )
        { // take out bit 1 from REG_MODEM_CONFIG1 indicates RxPayloadCrcOn
            state = 0;
//#if (SX1272_debug_mode > 1)
            Serial.println(F("## CRC has been desactivated ##"));
            Serial.println();
//#endif
        }


    if( state != 0 )
    {
        state = 1;
//#if (SX1272_debug_mode > 1)
        Serial.println(F("** There has been an error while setting CRC OFF **"));
        Serial.println();
//#endif
    }

}
