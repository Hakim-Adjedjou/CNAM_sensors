/********************************************************************************************
*	SX1280.h - Library for SX1280
*	Copyright(C) 2023 Cnam right reserved.  
*	@version 1  
*	This library is suit for LoRa1280 in loRa mode
*	please make sure the supply power of you board is UNDER 3.3V!! Otherwise, the module will be destory!!
*	The configuration of both the modules should be the same.
*********************************************************************************************/
#ifndef __SX1280_H__
#define __SX1280_H__

		/********************************************************************************
									!!!!!! ATTENTION !!!!!!
					TOUTES LES PAGES FONT REFERENCE A LA DATASHEET REV3.2
		*********************************************************************************/
		
// PAGE 71 à 97 DATASHEET DETAILLE DES REGISTRES ...
// PAGE 101 à 103 RECAPITULATIF TABLEAU DES REGISTRES ... 
#include "Arduino.h"

typedef struct
{
	uint32_t rf_freq;
	 int8_t  tx_power;
	uint8_t  lora_sf;
	uint8_t  band_width;
	uint8_t  code_rate;
	uint8_t	 payload_size;
	uint16_t RngCalib;           // Ranging Calibration
	double RngFeiFactor;         // Ranging frequency correction factor
	double RngFei;
	
}loRa_Para_t;


/*!
 * \brief Represents a calibration configuration
 */
typedef struct
{
    uint8_t RC64KEnable    : 1;                             //!< Calibrate RC64K clock
    uint8_t RC13MEnable    : 1;                             //!< Calibrate RC13M clock
    uint8_t PLLEnable      : 1;                             //!< Calibrate PLL
    uint8_t ADCPulseEnable : 1;                             //!< Calibrate ADC Pulse
    uint8_t ADCBulkNEnable : 1;                             //!< Calibrate ADC bulkN
    uint8_t ADCBulkPEnable : 1;                             //!< Calibrate ADC bulkP
}CalibrationParams_t;

typedef enum
{
    RANGING_IDCHECK_LENGTH_08_BITS          = 0x00,
    RANGING_IDCHECK_LENGTH_16_BITS,
    RANGING_IDCHECK_LENGTH_24_BITS,
    RANGING_IDCHECK_LENGTH_32_BITS,
}RadioRangingIdCheckLengths_t;


/******************* RADIO_SET_DIOIRQPARAMS  0x8D *******************/
#define    IRQ_RADIO_NONE                         0x0000
#define    IRQ_TX_DONE                            0x0001
#define    IRQ_RX_DONE                            0x0002
#define    IRQ_SYNCWORD_VALID                     0x0004
#define    IRQ_SYNCWORD_ERROR                     0x0008
#define    IRQ_HEADER_VALID                       0x0010
#define    IRQ_HEADER_ERROR                       0x0020     /* Voir PAGE 95  */
#define    IRQ_CRC_ERROR                          0x0040	
#define    IRQ_RANGING_SLAVE_RESPONSE_DONE        0x0080
#define    IRQ_RANGING_SLAVE_REQUEST_DISCARDED    0x0100
#define    IRQ_RANGING_MASTER_RESULT_VALID        0x0200
#define    IRQ_RANGING_MASTER_RESULT_TIMEOUT      0x0400
#define    IRQ_RANGING_SLAVE_REQUEST_VALID        0x0800
#define    IRQ_CAD_DONE                           0x1000
#define    IRQ_CAD_ACTIVITY_DETECTED              0x2000
#define    IRQ_RX_TX_TIMEOUT                      0x4000
#define    IRQ_PREAMBLE_DETECTED                  0x8000
#define    IRQ_RADIO_ALL                          0xFFFF

/**********************************************************/

/******************* RADIO_SET_MODULATIONPARAMS  0x8B *******************/
#define LORA_SF5   			0x50
#define LORA_SF6   			0x60
#define LORA_SF7   			0x70
#define LORA_SF8   			0x80			/*  Voir PAGE 130  */
#define LORA_SF9   			0x90
#define LORA_SF10  			0xA0      
#define LORA_SF11  			0xB0
#define	LORA_SF12  			0xC0
	
#define LORA_BW_0200   		0x34
#define LORA_BW_0400   		0x26			/*  Voir PAGE 131  */		
#define LORA_BW_0800   		0x18
#define LORA_BW_1600   		0x0A

#define LORA_CR_4_5       	0x01
#define LORA_CR_4_6       	0x02
#define LORA_CR_4_7       	0x03
#define LORA_CR_4_8       	0x04			/*  Voir PAGE 131  */
#define LORA_CR_LI_4_5    	0x05		
#define LORA_CR_LI_4_6    	0x06			
#define LORA_CR_LI_4_7    	0x07

/**********************************************************/

/****************** RECAPITULATIF LISTE COMMANDE AVEC LEUR OPCODE Voir PAGE 100-101 ******************/

#define RADIO_GET_STATUS                  0xC0
#define RADIO_WRITE_REGISTER              0x18
#define RADIO_READ_REGISTER               0x19
#define RADIO_WRITE_BUFFER                0x1A
#define RADIO_READ_BUFFER                 0x1B
#define RADIO_SET_SLEEP                   0x84
#define RADIO_SET_STANDBY                 0x80
#define RADIO_SET_FS                      0xC1
#define RADIO_SET_TX                      0x83
#define RADIO_SET_RX                      0x82
#define RADIO_SET_RXDUTYCYCLE             0x94
#define RADIO_SET_CAD                     0xC5
#define RADIO_SET_TXCONTINUOUSWAVE        0xD1
#define RADIO_SET_TXCONTINUOUSPREAMBLE    0xD2
#define RADIO_SET_PACKETTYPE              0x8A
#define RADIO_GET_PACKETTYPE              0x03
#define RADIO_SET_RFFREQUENCY             0x86			/*  Voir PAGE 100-101  */
#define RADIO_SET_TXPARAMS                0x8E
#define RADIO_SET_CADPARAMS               0x88
#define RADIO_SET_BUFFERBASEADDRESS       0x8F
#define RADIO_SET_MODULATIONPARAMS        0x8B
#define RADIO_SET_PACKETPARAMS            0x8C
#define RADIO_GET_RXBUFFERSTATUS          0x17
#define RADIO_GET_PACKETSTATUS            0x1D
#define RADIO_GET_RSSIINST                0x1F
#define RADIO_SET_DIOIRQPARAMS            0x8D
#define RADIO_GET_IRQSTATUS               0x15
#define RADIO_CLR_IRQSTATUS               0x97
#define RADIO_CALIBRATE                   0x89
#define RADIO_SET_REGULATORMODE           0x96
#define RADIO_SET_SAVECONTEXT             0xD5
#define RADIO_SET_AUTOTX                  0x98
#define RADIO_SET_AUTOFS                  0x9E
#define RADIO_SET_LONGPREAMBLE            0x9B
#define RADIO_SET_UARTSPEED               0x9D
#define RADIO_SET_RANGING_ROLE            0xA3



#define STDBY_RC     0x00
#define STDBY_XOSC   0x01

#define REG_LR_PACKETPARAMS                         0x903
#define REG_LR_PAYLOADLENGTH                        0x901

#define PERIOBASE_15_US    0x00
#define PERIOBASE_62_US    0x01
#define PERIOBASE_01_MS    0x02
#define PERIOBASE_04_MS    0x03

#define PACKET_TYPE_GFSK    0x00                  
#define	PACKET_TYPE_LORA	0x01
#define PACKET_TYPE_RANGING	0x02
#define PACKET_TYPE_FLRC	0x03
#define PACKET_TYPE_BLE		0x04

#define RADIO_RAMP_02_US    0x00
#define RADIO_RAMP_04_US    0x20
#define RADIO_RAMP_06_US    0x40
#define RADIO_RAMP_08_US    0x60
#define RADIO_RAMP_10_US    0x80
#define RADIO_RAMP_12_US    0xA0
#define RADIO_RAMP_16_US	0xC0
#define RADIO_RAMP_20_US	0xE0

#define LORA_CAD_01_SYMBOL	0x00
#define LORA_CAD_02_SYMBOL	0x20
#define LORA_CAD_04_SYMBOL	0x40
#define LORA_CAD_08_SYMBOL	0x60
#define LORA_CAD_16_SYMBOL	0x80

#define    LORA_PACKET_VARIABLE_LENGTH            0x00    //!< Taille variable du paquet, header inclus
#define    LORA_PACKET_FIXED_LENGTH               0x80    //!< Taille du paquet connu des 2 cotés, header non inclus dans le paquet
#define    LORA_PACKET_EXPLICIT                   LORA_PACKET_VARIABLE_LENGTH
#define    LORA_PACKET_IMPLICIT                   LORA_PACKET_FIXED_LENGTH

#define    LORA_CRC_ON                            0x20        //!< CRC activé
#define    LORA_CRC_OFF                           0x00         //!< CRC non activé

#define    LORA_IQ_NORMAL                         0x40
#define    LORA_IQ_INVERTED                       0x00

#define    USE_LDO     0x00           //! pour utiliser LDO (valeur par défaut)
#define    USE_DCDC    0x01           //! Pour utiliser DCDC

#define REG_LR_DEVICERANGINGADDR                    0x0916
#define REG_LR_REQUESTRANGINGADDR                   0x0912
#define REG_LR_RANGINGIDCHECKLENGTH                 0x0931

#define RANGING_IDCHECK_LENGTH_08_BITS    	0x00
#define RANGING_IDCHECK_LENGTH_16_BITS		0x01
#define RANGING_IDCHECK_LENGTH_24_BITS		0x02
#define RANGING_IDCHECK_LENGTH_32_BITS		0x03

#define  RANGING_RESULT_RAW           0x00
#define  RANGING_RESULT_AVERAGED      0x01
#define  RANGING_RESULT_DEBIASED      0x02
#define  RANGING_RESULT_FILTERED      0x03

#define REG_LR_RANGINGRESULTCONFIG                  0x0924
#define MASK_RANGINGMUXSEL                          0xCF
#define REG_LR_RANGINGRESULTBASEADDR                0x0961
#define REG_LR_RANGINGRERXTXDELAYCAL                0x092C

#define     RADIO_RANGING_ROLE_SLAVE     0x00
#define     RADIO_RANGING_ROLE_MASTER    0x01

/*!
 * \brief Select high sensitivity versus power consumption
 */
#define REG_LNA_REGIME                              0x0891
#define MASK_LNA_REGIME                             0xC0

/*
 * \brief Register and mask controling the enabling of manual gain control
 */
#define REG_ENABLE_MANUAL_GAIN_CONTROL     0x089F
#define MASK_MANUAL_GAIN_CONTROL           0x80


/*!
 * \brief Register and mask controling the demodulation detection
 */
#define REG_DEMOD_DETECTION                0x0895
#define MASK_DEMOD_DETECTION               0xFE

/*!
 * Register and mask to set the manual gain parameter
 */
#define REG_MANUAL_GAIN_VALUE              0x089E
#define MASK_MANUAL_GAIN_VALUE             0xF0

/*!
 * \brief The MSB address and mask used to read the estimated frequency
 * error
 */
#define REG_LR_ESTIMATED_FREQUENCY_ERROR_MSB        0x0954
#define REG_LR_ESTIMATED_FREQUENCY_ERROR_MASK       0x0FFFFF


/*!
 * \brief The address of the register allowing to read ranging results
 *
 * \remark Only used for packet type Ranging
 */
#define REG_LR_RANGINGRESULTSFREEZE                 0x097F

/*!
 * \brief The address of the register holding the first byte of ranging calibration
 *
 * \remark Only used for packet type Ranging
 */
#define REG_LR_RANGINGRERXTXDELAYCAL                0x092C

/*!
 *\brief The address of the register holding the ranging filter window size
 *
 * \remark Only used for packet type Ranging
 */
#define REG_LR_RANGINGFILTERWINDOWSIZE              0x091E

/*!
 *\brief The address of the register to reset for clearing ranging filter
 *
 * \remark Only used for packet type Ranging
 */
#define REG_LR_RANGINGRESULTCLEARREG                0x0923


#define REG_RANGING_RSSI                            0x0964

/*!
 * \brief The default number of samples considered in built-in ranging filter
 */
#define DEFAULT_RANGING_FILTER_SIZE                 127
/*typedef enum
{
    RANGING_RESULT_RAW                      = 0x00,
    RANGING_RESULT_AVERAGED                 = 0x01,
    RANGING_RESULT_DEBIASED                 = 0x02,
    RANGING_RESULT_FILTERED                 = 0x03,
}RadioRangingResultTypes_t;

*/
typedef enum
{
    LNA_LOW_POWER_MODE,
    LNA_HIGH_SENSITIVITY_MODE,
}RadioLnaSettings_t;

const uint16_t DEMO_RNG_CHANNELS_COUNT_MAX = 255;
const uint16_t DEMO_RNG_CHANNELS_COUNT_MIN = 10;
extern int RngResultIndex;
extern double RawRngResults[DEMO_RNG_CHANNELS_COUNT_MAX];
extern double RssiRng[DEMO_RNG_CHANNELS_COUNT_MAX];

class SX1280
{
	
public:
	// Constructor.
	SX1280(uint8_t NSS_Pin = 13, uint8_t NRESET_Pin = 14,uint8_t BUSY_Pin = 22,uint8_t DIO1_Pin = 15); /*Cette fonction sert à initialiser Le module 
	Lora en lui affectant en paramètre et les paramètres de la transmission à travers le pointeur de la fonction bool ci-dessous*/
	bool Init(loRa_Para_t *lp_pt);
	bool Init_Ranging_Master(loRa_Para_t *lp_pt);
	bool Init_Ranging_Slave(loRa_Para_t *lp_pt);
	void TxPacket(uint8_t *payload,uint8_t size);
	uint8_t WaitForIRQ_TxDone(void); // Fonction permettant de s'assurer que la transmission Rf a bien été éxécutée
	void RxBufferInit(uint8_t *rxpayload,uint16_t *rx_size);
	void RxInit();/*Cette fonction sert à initialisé la position dans le buffer des données 
	à recevoir et à transmettre, à activer l'interruption liée à la bonne réception de donnée,
	et à effectuer
	*/
	uint8_t WaitForIRQ_RxDone_Bis(void);
	uint8_t WaitForIRQ_RxDone_GateWay(int Delai_Attente_Reponse);
        uint8_t WaitForIRQ_RxDone_GateWay(void);
	uint8_t WaitForIRQ_RangingDone_Master(void);
	void SX1280_Config_Ranging_MASTER(void);
	void StartRanging_Master(void);
	void SX1280_Config_Ranging_SLAVE(void);
	uint8_t WaitForIRQ_RangingDone_Slave(void);
	void Calibration(uint8_t BW,uint8_t SF);
	int32_t GetLoRaBandwidth(void);
	double GetFrequencyError(void);
	void SetRangingIdLength( uint8_t length );
	void SetDeviceRangingAddress( uint32_t address );
	void SetRangingRequestAddress( uint32_t address );
	double GetRangingResult( uint8_t resultType );
	void SetRangingCalibration( uint16_t cal );
	void RangingClearFilterResult( void );
	void RangingSetFilterNumSamples( uint8_t num );
	void SetRangingRole( uint8_t role );
	void EnableManualGain( void );
	void DisableManualGain( void );
	void SetManualGainValue( uint8_t gain );
	void SetLNAGainSetting( const RadioLnaSettings_t lnaSetting );
	int32_t complement2( const uint32_t num, const uint8_t bitCnt );
	void RxInit_Ranging(void);
	void RxInit_Ranging_Slave(void);
	void RxInit_Ranging_Master(void);
	uint8_t GetRangingPowerDeltaThresholdIndicator( void );
	uint8_t WaitForIRQ_TxDone_Ranging(void);
	void TxPacket_ranging(uint8_t *payload,uint8_t size);
	double CheckDistance( void );
	
	uint8_t WaitForIRQ_RxDone(void); // Fonction permettant de s'assurer que la reception Rf a bien été éxécutée
	void Reset_SX1280(void); // Fonction RESET du module LORA
	void SetSleep(void);  // Fonction Mise du mode Lora en mode Sleep(Sommeil)
	void RECONFIG(loRa_Para_t *lp_pt); // Fonction permettant de balayer les différents SF et BW en fonction de l'ID client si besoin
	void SetStandby(uint8_t StdbyConfig); // Fonction Mise en Standby du module LORA pour configuration
	void GetPacketStatus(int8_t *RssiPkt,int8_t *SnrPkt);
	void Affiche_BW(int bw_hexa);
	/*
		Cette fonction basé sur la commande GetPacketStatus() command permet de récupérer des informations(Rssi et SNR) sur le dernier paquet reçu
		à l'aide de l'OpCode 0x1D*/
	uint8_t *rxbuf_pt;
	//uint8_t *Adress_Payload_RX ;
	uint16_t *rxcnt_pt;
	void SetTxContinuousWave(void);
protected:
	void SPI_Init(void);	// Initialise SPI. @note Use standard Arduino SPI interface
	void Pin_Init(void);	//Initialise Les autres pin.
	void SX1280_Config(void);
	/*
    Cette fonction sert à configuer La transmission Lora avec laquelle on veut opérer 
    */
	/*!!!!!!!!!!!! A UTILISER POUR TRANSMETTRE AVEC UNE MODULATION LORA DIFFERENTE !!!!!!!!!!!!!!!!
	 SF Different, ... 
	*/ 
	uint8_t spi_rw(uint8_t value_w);  // Fonction servant à lire ou écrire à travers le port SPI
	void CheckBusy(void);   // Fonction permettant de vérifier si le module SX1280 est en plein traitement ou non 
	void WriteCommand(uint8_t Opcode, uint8_t *buffer, uint16_t size );  /* Fonction qui permet l'écriture/envoi de données voulu au module LORA 
	du module SX1280 
	Paramètre :
		Opcode: Code Commande permettant d'acceder aux registres concernés
		*buffer: Pointeur indiquant l'adresse des données à implémenter dans le registre indiquer par l'Opcode
		size: Nombre d'octet à transmettre dans le registre
	*/ 
	void ReadCommand( uint8_t Opcode, uint8_t *buffer, uint16_t size );
	/* Fonction permettant de lire/récupérer les données renvoyer par les commandes de lecture du module SX1280 
	Paramètre :
		Opcode: Code Commande permettant d'acceder aux registres concernés
		*buffer: Pointeur indiquant l'adresse des données à implémenter dans le registre indiquer par l'Opcode
		size: Nombre d'octet à récupérer
	*/ 
	void WriteRegisters( uint16_t address, uint8_t *buffer, uint16_t size );
	/*Cette fonction sert à écrire un bloc d'octets dans un espace mémoire de données à partir d'une adresse spécifique. 
	L'adresse est automatiquement incrémenté après chaque octet de données afin que les données soient stockées 
	dans des emplacements de mémoire voisins. 
	Paramètre:
		address: Adresse où écrire les données
		*buffer: donnée à écrire
		size: nombre d'octet à écrire
	*/
	void WriteRegister( uint16_t address, uint8_t value );
	/*Cette fonction fait appelle à la fonction WriteRegisters 
	Paramètre:
		address: Adresse où écrire les données
		value: donnée à écrire
	*/
	void ReadRegisters( uint16_t address, uint8_t *buffer, uint16_t size );
	/*
	Cette fonction à l'aide de la commande ReadRegister() lit un bloc de données à partir d'une adresse donnée. L'adresse est automatiquement 
	incrémentée après chaque octet. Le transfert de données SPI est décrit dans le Tableau 11-10 page 75 de la DATASHEET
	Lors de l'utilisation de SPI, l'hôte doit envoyer un NOP(No Opération 0x00 ou 0xFF) après avoir envoyé les 2 octets d'adresse pour commencer 
	à recevoir des octets de données sur le prochain NOP envoyé.
	Paramètre:
		address: Adresse du registre à lire
		*buffer: Pointeur permettant de récupérer l'état du registre
		size: Nombre d'octet nécessaire pour la récupération de l'état du registre
	*/
	
	uint8_t ReadRegister( uint16_t address );
	/*Cette fonction fait appelle à la fonction ReadRegisters 
	Paramètre:
		address: Adresse du registre à lire
	*/
	
	void WriteBuffer(uint8_t offset, uint8_t *data, uint8_t length);
	/*
	Cette fonction est utilisée pour écrire le payload à transmettre. L'adresse est auto-incrémentée, lorsque l'adresse
	dépasse 255, il revient à 0 en raison de la nature circulaire du tampon de données. L'adresse commence à partir de l'offset donné comme
	paramètre de la fonction
	Paramètre:
		offset: Adresse de départ pour l'écriture dans le buffer de données à transmettre
		*data: pointeur sur les datas à transmettre
		length: taille en octet des datas à transmettre en rf à écrire dans le buffer
	*/
	void ReadBuffer(uint8_t offset, uint8_t *data, uint8_t length);
	/*
	Cette fonction permet de lire (n-3) octets du payload reçues à partir de l'offset.
	Paramètre:
		offset: Adresse de départ pour la lecture dans le buffer des données à récupérer
		*data: pointeur sur la zone allouée pour la récupération des datas
		length: taille en octet des datas à récupérer dans le buffer
	*/
	
	void SetTx(uint8_t periodBase, uint16_t periodBaseCount);
	/*
	Cette fonction met le Module Lora en mode transmission à laide de l'OpCode 0x83 SetTx() 
	Il faut effacer l'état IRQ avant d'utiliser cette commande
	Paramètre:
		periodBase: unité d'un pas incrémentation temporelle
		periodBasecount: contient le nombre de pas souhaité afin d'établir le temps avant d'exectuter Le Timeout
		Timeout =(periodBase*periodBaseCount)
	*/
	void SetRx(uint8_t periodBase, uint16_t periodBaseCount);
	/*
	Cette fonction met l'appareil en mode Récepteur. à l'aide de la commande SetRx() qui a pour Opcode 0x82 
	L'état IRQ doit être effacé avant d'utiliser cette commande,
	Paramètre:
		periodBase: unité d'un pas incrémentation temporelle
		periodBasecount: contient le nombre de pas souhaité afin d'établir le temps avant d'exectuter Le Timeout
		Timeout =(periodBase*periodBaseCount)
	*/

	void SetPacketType( uint8_t packetType );
	/*
	!!!!!!!!!!!!!!!!! La commande SetPacketType() doit être la première d'une séquence de configuration radio.!!!!!!!!!!!!!!!!!
	La Fonction à l'aide de la commande SetPacketType() définit la trame radio de l'émetteur-récepteur 
	parmi un choix de 5 types de paquets différents ci-dessus. Pour nous  PACKET_TYPE_LORA 		0x01
	*/
	uint8_t GetPacketType(void);
	/*
    Cette fonction renvoie le type de paquet de fonctionnement actuel de la radio.
	à l'aide de la commande GetPacketType() qui a pour Opcode 0x03
	*/
	void SetRfFrequency( uint32_t frequency );
		/*
	Cette fonction sert à définir la fréquence de transmission.
	à l'aide de la commande SetRfFrequency() qui a pour Opcode 0x86
	Paramètre:
		frequency : fréquence émission/réception
	
	*/
	void SetTxParams( int8_t power, uint8_t rampTime );
		/*
	Cette fonction sert à définir la puissance de sortie Tx à l'aide du paramètre power et le temps de rampe Tx à 
	l'aide du paramètre rampTime. La commande est disponible pour tous les Types de Paquets.
	Paramètre: power: puissance entre [-18..13]dBm
			   ramptime: temps donné pour atteindre la puissance voulue
	*/
	void SetBufferBaseAddress( uint8_t txBaseAddress, uint8_t rxBaseAddress );
		/* 
    Cette fonction fixe l'adresse de base pour l'opération de traitement des paquets en mode Tx et Rx
	pour tous les types de paquets 
	Paramètre:
		txBaseAdress: adresse début buffer pour la transmission
		rxBaseAdress: adresse début buffer pour la reception
    */
	void SetModulationParams(uint8_t sf, uint8_t bw, uint8_t cr);
		/*
		Cette fonction permet d'implementer les paramétres de la Modulation Radio LORA à l'aide de la commande 
		SetModulationParams() qui a pour OpCode 0x8B
	Paramètre: 
		sf:SF(Spreading Factor),
		bw:BW(Bande Utile), 
		cr:CR (Coding Rate)
	*/
	void AfterSetModulationParams(uint8_t sf);
		/*Page 131 indiqué d'implementer selon le spreading factor des valeur dans le registre à l'adresse 0x925
		En utilisant la commande writeregister
	Paramètre: 
		sf:SF(Spreading Factor),
	*/
	void SetPacketParams(uint8_t payload_len);/*
    	Cette fonction sert à définir les paramètres du paquet à envoyer à l'aide de la commande Set de l'Opcode 8C.
	Paramètre:
		Payload: Taille du payload à transmettre
	*/
	void GetRxBufferStatus( uint8_t *payloadLength, uint8_t *rxStartBufferPointer );
	/*
		Cette Fonction permet de récupérer la taille du Payload et l'adresse de départ de celui-ci
		à l'aide de la commande RADIO_GET_RXBUFFERSTATUS qui renvoie la longueur du dernier paquet reçu (payloadLengthRx) 
		et l'adresse du premier octet reçu(rxBufferOffset), il est applicable à tous les modems. L'adresse est un offset 
		relatif au premier octet du Buffer.
	Paramètre:
		*payload_len: pointeur servant à récupérer la taille du payload reçu
		*rxSartBufferPointer: pointeur permettant de récupérer l'endroit ou récupérer les données reçu
	*/
	//void GetPacketStatus(int8_t *RssiPkt,int8_t *SnrPkt);
	/*
		Cette fonction basé sur la commande GetPacketStatus() command permet de récupérer des informations(Rssi et SNR) sur le dernier paquet reçu
		à l'aide de l'OpCode 0x1D
	*/
	int8_t GetRssiInst( void ); /*
    	Cette fonction permet de récupérer le RSSI instanée qui provient du dernier paquet reçu
    */
	void SetDioIrqParams(uint16_t irq);//********** page 86 ********** Tableau 11-74
	/* 
		Fonction servant à activer les Interruptions 
	*/
	uint16_t GetIrqStatus( void );// ********** page 97 datasheet **********
	 /*
     	Cette fonction serrt à récuperer le status des interruptions
     */
	void ClearIrqStatus( uint16_t irq );  // ********** page 97 datasheet ********** Tableau 11-78
	/* 
     	Cette fonction sert à mettre les drapeau d'interruption à 0 
     */
	void SetRegulatorMode( uint8_t mode );		// ********** page 143 datasheet **********
	/* 
		Cette fonction à travers la commande qui a pour OpCode 0x96 permet à l'utilisateur 
		pour spécifier si DC-DC ou LDO est utilisé pour la régulation de puissance. Par défaut, le LDO est activé. 
	*/
	void SetSaveContext( void );

	void SetRxDutyCycle(uint8_t PeriodBase, uint16_t NbStepRx, uint16_t RxNbStepSleep );
	void SetLongPreamble( uint8_t enable );
	void SetCad( void );
	//void SetTxContinuousWave( void );
	void SetTxContinuousPreamble( void );
	void SetCadParams( uint8_t cadSymbolNum );
	
private:
	uint8_t SPI_NSS;	//output,SPI pin selectionnant l'ESCLAVE
	uint8_t RF_NRESET;	//output,HARD RESET du module LORA
	uint8_t RF_BUSY;	//input, indique si le module LORA est en cours de traitement ou libre
	uint8_t RF_DIO1;	//input indique si il y a interruption ou non
	
};

#endif


