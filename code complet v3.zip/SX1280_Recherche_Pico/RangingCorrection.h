#ifndef __SX1280_RANGING_CORRECTION_H__
#define __SX1280_RANGING_CORRECTION_H__

#include "SX1280_Recherche_pico.h"


double GetRangingCorrectionPerSfBwGain( uint8_t sf, uint8_t bw, int8_t gain);
double ComputeRangingCorrectionPolynome(uint8_t sf, uint8_t bw, const double median);


#endif // __SX1280_RANGING_CORRECTION_H__
