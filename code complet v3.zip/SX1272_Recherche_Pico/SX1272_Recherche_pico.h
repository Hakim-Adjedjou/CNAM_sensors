/*
 * LoRaFi.h version 1.3.0
 *
 *  Created on: May 13, 2017
 *      Authors: KHUDHUR ABDULLAH ALFARHAN and Dr. Ammar Zakaria
 *      Email: Qudoren@gmail.com , ammarzakaria@unimap.edu.my
 *
 *  This library licensed under GNU General Public License (GPL)
 *  and supported by Centre of Excellence for Advanced Sensor Technology (CEASTech)
 *  https://ceastech.com/
 *  Universiti Malaysia Perlis (UniMAP)
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 */

#ifndef SX1272_H
#define SX1272_H

//Include required libraries
//#include <Arduino.h>
#include <SPI.h>
#include <string.h>
//#include <WString.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>



typedef struct
{
	uint32_t rf_freq;
	 int8_t  tx_power;
	uint8_t  lora_sf;
	uint16_t  band_width;
	uint8_t  code_rate;
	//uint8_t	 payload_size;
	
}loRa_Para_t_SX1272;


using namespace std;

//Define modes
#define SLEEP			0x00
#define STANDBY			0x01
//#define LORA			0x80
#define TX			0x03
#define RX_CONTINUOUS		0x05
#define RX			0x06

//Define Registers
#define POWER_REGISTER		0x09
//! MACROS //
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)  // read a bit
#define bitSet(value, bit) ((value) |= (1UL << (bit)))    // set bit to '1'
#define bitClear(value, bit) ((value) &= ~(1UL << (bit))) // set bit to '0'

//! REGISTERS //

#define        REG_FIFO        					0x00
#define        REG_OP_MODE        				0x01
#define        REG_BITRATE_MSB    				0x02
#define        REG_BITRATE_LSB    				0x03
#define        REG_FDEV_MSB   					0x04
#define        REG_FDEV_LSB    					0x05
#define        REG_FRF_MSB    					0x06
#define        REG_FRF_MID    					0x07
#define        REG_FRF_LSB    					0x08
#define        REG_PA_CONFIG    				0x09
#define        REG_PA_RAMP    					0x0A
#define        REG_OCP    						0x0B
#define        REG_LNA    						0x0C
#define        REG_RX_CONFIG    				0x0D
#define        REG_FIFO_ADDR_PTR  				0x0D
#define        REG_RSSI_CONFIG   				0x0E
#define        REG_FIFO_TX_BASE_ADDR 		    0x0E
#define        REG_RSSI_COLLISION    			0x0F
#define        REG_FIFO_RX_BASE_ADDR   			0x0F
#define        REG_RSSI_THRESH    				0x10
#define        REG_FIFO_RX_CURRENT_ADDR   		0x10
#define        REG_RSSI_VALUE_FSK	    		0x11
#define        REG_IRQ_FLAGS_MASK    			0x11
#define        REG_RX_BW		    			0x12
#define        REG_IRQ_FLAGS	    			0x12
#define        REG_AFC_BW		    			0x13
#define        REG_RX_NB_BYTES	    			0x13
#define        REG_OOK_PEAK	    				0x14
#define        REG_RX_HEADER_CNT_VALUE_MSB  	0x14
#define        REG_OOK_FIX	    				0x15
#define        REG_RX_HEADER_CNT_VALUE_LSB  	0x15
#define        REG_OOK_AVG	 					0x16
#define        REG_RX_PACKET_CNT_VALUE_MSB  	0x16
#define        REG_RX_PACKET_CNT_VALUE_LSB  	0x17
#define        REG_MODEM_STAT	  				0x18
#define        REG_PKT_SNR_VALUE	  			0x19
#define        REG_AFC_FEI	  					0x1A
#define        REG_PKT_RSSI_VALUE	  			0x1A
#define        REG_AFC_MSB	  					0x1B
#define        REG_RSSI_VALUE_LORA	  			0x1B
#define        REG_AFC_LSB	  					0x1C
#define        REG_HOP_CHANNEL	  				0x1C
#define        REG_FEI_MSB	  					0x1D
#define        REG_MODEM_CONFIG1	 		 	0x1D
#define        REG_FEI_LSB	  					0x1E
#define        REG_MODEM_CONFIG2	  			0x1E
#define        REG_PREAMBLE_DETECT  			0x1F
#define        REG_SYMB_TIMEOUT_LSB  			0x1F
#define        REG_RX_TIMEOUT1	  				0x20
#define        REG_PREAMBLE_MSB_LORA  			0x20
#define        REG_RX_TIMEOUT2	  				0x21
#define        REG_PREAMBLE_LSB_LORA  			0x21
#define        REG_RX_TIMEOUT3	 				0x22
#define        REG_PAYLOAD_LENGTH_LORA		 	0x22
#define        REG_RX_DELAY	 					0x23
#define        REG_MAX_PAYLOAD_LENGTH 			0x23
#define        REG_OSC		 					0x24
#define        REG_HOP_PERIOD	  				0x24
#define        REG_PREAMBLE_MSB_FSK 			0x25
#define        REG_FIFO_RX_BYTE_ADDR 			0x25
#define        REG_PREAMBLE_LSB_FSK 			0x26
// added by C. Pham
#define        REG_MODEM_CONFIG3	  			0x26
// end
#define        REG_SYNC_CONFIG	  				0x27
#define        REG_SYNC_VALUE1	 				0x28
#define        REG_SYNC_VALUE2	  				0x29
#define        REG_SYNC_VALUE3	  				0x2A
#define        REG_SYNC_VALUE4	  				0x2B
#define        REG_SYNC_VALUE5	  				0x2C
#define        REG_SYNC_VALUE6	  				0x2D
#define        REG_SYNC_VALUE7	  				0x2E
#define        REG_SYNC_VALUE8	  				0x2F
#define        REG_PACKET_CONFIG1	  			0x30
#define        REG_PACKET_CONFIG2	  			0x31
#define        REG_DETECT_OPTIMIZE              0x31
#define        REG_PAYLOAD_LENGTH_FSK			0x32
// added by C. Pham
#define        REG_INVERT_IQ	  				0x33
#define        REG_INVERT_IQ2	  				0x3B
#define        REG_BROADCAST_ADRS	 		 	0x34
#define        REG_FIFO_THRESH	  				0x35
#define        REG_SEQ_CONFIG1	  				0x36
#define        REG_SEQ_CONFIG2	  				0x37
#define        REG_DETECTION_THRESHOLD          0x37
#define        REG_TIMER_RESOL	  				0x38
// added by C. Pham
#define        REG_SYNC_WORD                    0x39
//end
#define        REG_TIMER1_COEF	  				0x39
#define        REG_TIMER2_COEF	  				0x3A
#define        REG_IMAGE_CAL	  				0x3B
#define        REG_TEMP		  					0x3C
#define        REG_LOW_BAT	  					0x3D
#define        REG_IRQ_FLAGS1	  				0x3E
#define        REG_IRQ_FLAGS2	  				0x3F
#define        REG_DIO_MAPPING1	  				0x40
#define        REG_DIO_MAPPING2	  				0x41
#define        REG_VERSION	  					0x42
#define        REG_AGC_REF	  					0x43
#define        REG_AGC_THRESH1	  				0x44
#define        REG_AGC_THRESH2	  				0x45
#define        REG_AGC_THRESH3	  				0x46
#define        REG_PLL_HOP	  					0x4B
#define        REG_TCXO		  					0x58
#define        REG_PA_DAC		  				0x5A
#define        REG_PLL		  					0x5C
#define        REG_PLL_LOW_PN	  				0x5E
#define        REG_FORMER_TEMP	  				0x6C
#define        REG_BIT_RATE_FRAC	  			0x70



#define RF_IMAGECAL_TEMPCHANGE_HIGHER               0x08
#define RF_IMAGECAL_TEMPCHANGE_LOWER                0x00

#define RF_IMAGECAL_TEMPTHRESHOLD_MASK              0xF9
#define RF_IMAGECAL_TEMPTHRESHOLD_05                0x00
#define RF_IMAGECAL_TEMPTHRESHOLD_10                0x02  // Default
#define RF_IMAGECAL_TEMPTHRESHOLD_15                0x04
#define RF_IMAGECAL_TEMPTHRESHOLD_20                0x06

#define RF_IMAGECAL_TEMPMONITOR_MASK                0xFE
#define RF_IMAGECAL_TEMPMONITOR_ON                  0x00 // Default
#define RF_IMAGECAL_TEMPMONITOR_OFF                 0x01

// added by C. Pham
// The crystal oscillator frequency of the module
#define RH_LORA_FXOSC 32000000.0
 
// The Frequency Synthesizer step = RH_LORA_FXOSC / 2^^19
#define RH_LORA_FCONVERT  (524288 / RH_LORA_FXOSC)

// Frf = frf(Hz)*2^19/RH_LORA_FXOSC

/////

//FREQUENCY CHANNELS:
// added by C. Pham for Senegal
/*
#define CH_04_868		863200000
#define CH_05_868		863500000
#define CH_06_868		863800000
#define CH_07_868		864100000
#define CH_08_868		864400000
#define CH_09_868		864700000
#define CH_10_868		865200000
#define CH_11_868		865500000
#define CH_12_868		865800000
#define CH_13_868		866100000
#define CH_14_868		866400000
#define CH_15_868		866700000
#define CH_16_868		867000000
#define CH_17_868		868000000
#define CH_18_868		868100000

*/

const uint32_t CH_04_868 = 0xD7CCCC; // channel 04, central freq = 863.20MHz
const uint32_t CH_05_868 = 0xD7E000; // channel 05, central freq = 863.50MHz
const uint32_t CH_06_868 = 0xD7F333; // channel 06, central freq = 863.80MHz
const uint32_t CH_07_868 = 0xD80666; // channel 07, central freq = 864.10MHz
const uint32_t CH_08_868 = 0xD81999; // channel 08, central freq = 864.40MHz
const uint32_t CH_09_868 = 0xD82CCC; // channel 09, central freq = 864.70MHz
//
const uint32_t CH_10_868 = 0xD84CCC; // channel 10, central freq = 865.20MHz, = 865200000*RH_LORA_FCONVERT
const uint32_t CH_11_868 = 0xD86000; // channel 11, central freq = 865.50MHz
const uint32_t CH_12_868 = 0xD87333; // channel 12, central freq = 865.80MHz
const uint32_t CH_13_868 = 0xD88666; // channel 13, central freq = 866.10MHz
const uint32_t CH_14_868 = 0xD89999; // channel 14, central freq = 866.40MHz
const uint32_t CH_15_868 = 0xD8ACCC; // channel 15, central freq = 866.70MHz
const uint32_t CH_16_868 = 0xD8C000; // channel 16, central freq = 867.00MHz
const uint32_t CH_17_868 = 0xD90000; // channel 17, central freq = 868.00MHz

// added by C. Pham
const uint32_t CH_18_868 = 0xD90666; // 868.1MHz for LoRaWAN test
// end

const uint32_t CH_00_900 = 0xE1C51E; // channel 00, central freq = 903.08MHz
const uint32_t CH_01_900 = 0xE24F5C; // channel 01, central freq = 905.24MHz
const uint32_t CH_02_900 = 0xE2D999; // channel 02, central freq = 907.40MHz
const uint32_t CH_03_900 = 0xE363D7; // channel 03, central freq = 909.56MHz
const uint32_t CH_04_900 = 0xE3EE14; // channel 04, central freq = 911.72MHz
const uint32_t CH_05_900 = 0xE47851; // channel 05, central freq = 913.88MHz
const uint32_t CH_06_900 = 0xE5028F; // channel 06, central freq = 916.04MHz
const uint32_t CH_07_900 = 0xE58CCC; // channel 07, central freq = 918.20MHz
const uint32_t CH_08_900 = 0xE6170A; // channel 08, central freq = 920.36MHz
const uint32_t CH_09_900 = 0xE6A147; // channel 09, central freq = 922.52MHz
const uint32_t CH_10_900 = 0xE72B85; // channel 10, central freq = 924.68MHz
const uint32_t CH_11_900 = 0xE7B5C2; // channel 11, central freq = 926.84MHz
const uint32_t CH_12_900 = 0xE4C000; // default channel 915MHz, the module is configured with it

// added by C. Pham
const uint32_t CH_00_433 = 0x6C5333; // 433.3MHz
const uint32_t CH_01_433 = 0x6C6666; // 433.6MHz
const uint32_t CH_02_433 = 0x6C7999; // 433.9MHz
const uint32_t CH_03_433 = 0x6C9333; // 434.3MHz
// end

//LORA BANDWIDTH:
// modified by C. Pham
const uint8_t BW_125 = 0x00;
const uint8_t BW_250 = 0x01;
const uint8_t BW_500 = 0x02;


const double SignalBwLog[] =
{
    5.0969100130080564143587833158265,
    5.397940008672037609572522210551,
    5.6989700043360188047862611052755
};

//LORA CODING RATE:
const uint8_t CR_5 = 0x01;
const uint8_t CR_6 = 0x02;
const uint8_t CR_7 = 0x03;
const uint8_t CR_8 = 0x04;

//LORA SPREADING FACTOR:
const uint8_t SF_6 = 0x06;
const uint8_t SF_7 = 0x07;
const uint8_t SF_8 = 0x08;
const uint8_t SF_9 = 0x09;
const uint8_t SF_10 = 0x0A;
const uint8_t SF_11 = 0x0B;
const uint8_t SF_12 = 0x0C;

//LORA MODES:
const uint8_t LORA_SLEEP_MODE = 0x80;
const uint8_t LORA_STANDBY_MODE = 0x81;
const uint8_t LORA_TX_MODE = 0x83;
const uint8_t LORA_RX_MODE = 0x85;

const uint8_t FSK_SLEEP_MODE = 0x00;

const uint8_t LORA_CAD_MODE = 0x87;
#define LNA_MAX_GAIN                0x23
#define LNA_OFF_GAIN                0x00
#define LNA_LOW_GAIN		    0x20
// end

const uint8_t LORA_STANDBY_FSK_REGS_MODE = 0xC1;



//OTHER CONSTANTS:

const uint8_t HEADER_ON = 0;
const uint8_t HEADER_OFF = 1;
const uint8_t CRC_ON = 1;
const uint8_t CRC_OFF = 0;
const uint8_t LORA = 1;
const uint8_t FSK = 0;
const uint8_t BROADCAST_0 = 0x00;
const uint8_t MAX_LENGTH = 255;
const uint8_t MAX_PAYLOAD = 251;

// modified by C. Pham to remove the retry field and the length field
// which will be replaced by packet type field
const uint8_t OFFSET_PAYLOADLENGTH = 4;
//#endif
const uint8_t OFFSET_RSSI = 139;

const uint8_t CORRECT_PACKET = 0;
const uint8_t INCORRECT_PACKET = 1;
const uint8_t INCORRECT_PACKET_TYPE = 2;


#define INVERT_IQ_RX			0x00
#define INVERT_IQ_TX			0x01

//Define defult pins
#define CS		9
#define RST		7
#define RX_SW		3
#define TX_SW		4
#define DIO0		5

//Define other variables 
#define DEFAULT_SPREADING_FACTOR	7
#define DEFAULT_BW			125000
#define DEFAULT_PACKAGE_LENGTH		10
#define DEFAULT_FREQUENCY		868000000
#define DEFAUL_C_RATE			5
#define DEFAULT_PREAMBLE_LENGTH		8
#define DEFAULT_SW			0x34
#define MAX_POWER			0x8F
#define NORMAL_POWER			0x0F
#define DEFAULT_DIGIT_NO		2
#define ON						1
#define OFF						0


class SX1272
{
   public:
		SX1272(uint8_t cs = CS, uint8_t rst = RST, uint8_t rx_sw = RX_SW, uint8_t tx_sw = TX_SW, uint8_t dio0 = DIO0);
		
        bool begin(loRa_Para_t_SX1272 *lp_pt);
		
		bool Reconfiguration(loRa_Para_t_SX1272 *lp_pt);
		
		void Write_Register(uint8_t address, uint8_t data);
		
		uint8_t Read_Register(uint8_t address);
		
		uint8_t readRegister(uint8_t address);
		
		void writeRegister(uint8_t address, uint8_t data);
		
		void Mode(uint8_t mode = SLEEP);
		
		void setLORA();
		
		void GetPacketStatus(int8_t* SNR_R, int16_t* RSSIpacket_R);
		
		void setMode(uint8_t BW,uint8_t SF);
		
		void setCR(uint8_t cod);
		
		void setBW(uint16_t band, uint8_t SF);
		
		void AfficheBW(uint8_t BW);
		
		void setChannel(uint32_t ch);
		
		void setSF(uint8_t SF ,uint8_t BW);
		
		void setHeaderON(uint8_t SF);
		
		void setHeaderOFF();
		
		void setPreambleLength(uint16_t l);
		
		uint8_t getPayloadLength();
		
		void setPower(uint8_t pow);
		
		void setPowerMax();
		
		int8_t setMaxCurrent(uint8_t rate);
		
		void clearFlags();
		
		void RSSI(int16_t* RSSI);
		
		void RSSIpacket(int8_t SNR, int16_t* RSSIpacket);
		
		void sleep(void);
		
		void idle(void);
		
		void TXpower(uint8_t pow = NORMAL_POWER);
		
		void SendPackage(char *Package, uint8_t packageLength = DEFAULT_PACKAGE_LENGTH);
		
		//uint8_t SendPackage(char *Package, uint8_t packageLength);
		
		uint8_t ReceivePackage(char *Package, uint8_t packageLength);
		
		uint8_t ReceivePackageGateWay(char *Package, uint8_t packageLength,uint32_t Delai_Attente_Reponse);
		
		void ReceivePackage(char *Package);
		
		void ChannelFrequency(long frequency);
		
		void setCRC_OFF();
		
		void setCRC_ON();
		
		void end(void);
		
		void SpreadingFactor(uint8_t SF = DEFAULT_SPREADING_FACTOR);
		
		void Bandwidth(long bw = DEFAULT_BW);
		
		void CodingRate(uint8_t C_Rate = DEFAUL_C_RATE);
		
		void PreambleLength(uint16_t length = DEFAULT_PREAMBLE_LENGTH);
		
		void SyncWord(uint8_t sw = DEFAULT_SW);

		void reset(void);

		int16_t Rssi(void);

		int16_t PacketRssi(void);

		//float SNR(void);
		void SNR(int8_t* SNR);

		void ReceivingInterrupt(void (*userFunction)(void));

		void CancelInterrupt(void);
		
		void FrequencyHopping(uint8_t FH = ON);
		
		void CRC(uint8_t crc = ON);
		
		void LDRoptimize(uint8_t ldr = ON);

		//Habdling data for send
		uint8_t Send(const char[]);	// send char array

		uint8_t Send(char);		// send char

		uint8_t Send(unsigned char);	// send unsigned char

		uint8_t Send(int);			// send int

		uint8_t Send(unsigned int);	// send unsigend 

		uint8_t Send(long);		// send long 

		uint8_t Send(unsigned long);	// send unsigned long 

		uint8_t Send(double package, uint8_t digit = DEFAULT_DIGIT_NO); // sned double

		uint8_t Send(const String &s);	// send constant string 

		
		//Habdling received data
		int ReceiveInt(void);			//receive int value

		unsigned int ReceiveUint(void);		//receive unsigned int value

		double ReceiveDouble(void);		//receive double value

		char ReceiveChar(void);  		// receive char 
	
		unsigned char ReceiveUchar(void);	// receive unsigned char

		long ReceiveLong(void);			// receive long

		unsigned long ReceiveUlong(void);	// receive unsigned long
	
	
private: 

	uint8_t SX1272Pins[5];
	bool interrupt = false;

	void SetInterrupt(void);	// configure receiving interrupt

	// to convert from long to char vice versa
	union{
		char union_char[4];
		long union_long;
		 } long_conv;

	// to convert from unsigned long to char vice versa
	union{
		char union_char[4];
		unsigned long union_Ulong;
		 } Ulong_conv;

	
};




#endif

