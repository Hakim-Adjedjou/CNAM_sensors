/********************************************************************************************
*	SX1280.cpp - Library for SX1280
*	Copyright(C) 2018 NiceRF.All right reserved.  
*	@version 1.1  
*	This library is suit for LoRa1280 in loRa mode
*	please make sure the supply of you board is UNDER 3.3V!! Otherwise, the module will be destory!!
*	The configuration of both the modules should be the same.
*********************************************************************************************/
#include <SPI.h>
#include <SoftwareSerial.h>
#include <SX1280_Recherche.h>
//#include "RangingCorrection.h"
//#include "string.h"

		/********************************************************************************
									!!!!!! ATTENTION !!!!!!
					TOUTES LES PAGES FONT REFERENCE A LA DATASHEET REV3.2
		*********************************************************************************/
/*
******************** PROCEDURE EMISSION RECEPTION LORA PAGES 133 à 135 DATASHEET ********************
*/

#define SPI_NSS_LOW()  digitalWrite(SPI_NSS, LOW)
#define SPI_NSS_HIGH() digitalWrite(SPI_NSS, HIGH)




double t0 =       -0.016432807883697;                         // X0
double t1 =       0.323147003165358;                          // X1
double t2 =       0.014922061351196;                          // X1^2
double t3 =       0.000137832006285;                          // X1^3
double t4 =       0.536873856625399;                          // X2
double t5 =       0.040890089178579;                          // X2^2
double t6 =       -0.001074801048732;                         // X2^3
double t7 =       0.000009240142234;                          // X2^4


double p[8] = { 0,
                -4.1e-9,
                1.03e-7,
                1.971e-5,
                -0.00107,
                0.018757,
                0.869171,
                3.072450 };


/*!
 * \brief Size of ticks (used for Tx and Rx timeout)
 */
#define RX_TIMEOUT_TICK_SIZE            RADIO_TICK_SIZE_1000_US

#define RNG_TIMER_MS                    384 // ms
#define RNG_COM_TIMEOUT                 100 // ms

/*!
 * \brief Ranging raw factors
 *                                  SF5     SF6     SF7     SF8     SF9     SF10
 */
const uint16_t RNG_CALIB_0400[] = { 10299,  10271,  10244,  10242,  10230,  10246  };
const uint16_t RNG_CALIB_0800[] = { 11486,  11474,  11453,  11426,  11417,  11401  };
const uint16_t RNG_CALIB_1600[] = { 13308,  13493,  13528,  13515,  13430,  13376  };
const double   RNG_FGRAD_0400[] = { -0.148, -0.214, -0.419, -0.853, -1.686, -3.423 };
const double   RNG_FGRAD_0800[] = { -0.041, -0.811, -0.218, -0.429, -0.853, -1.737 };
const double   RNG_FGRAD_1600[] = { 0.103,  -0.041, -0.101, -0.211, -0.424, -0.87  };

static uint8_t CurrentChannel;
static uint16_t MeasuredChannels;
int RngResultIndex;
double RawRngResults[DEMO_RNG_CHANNELS_COUNT_MAX];
double RssiRng[DEMO_RNG_CHANNELS_COUNT_MAX];



/*
The TCXO is 32MHz, so the frequency step should be FREQ_STEP = 52e6 / (2^18) Hz
*/
#define FREQ_STEP    198.364

static loRa_Para_t *lora_para_pt;	//pointeur contenant les paramètres LORA provenant de la couche application

SX1280::SX1280(uint8_t NSS_Pin, uint8_t NRESET_Pin,uint8_t BUSY_Pin,uint8_t DIO1_Pin)
{
	/*
    Cette fonction sert à initialiser Le module Lora en lui affectant les broches ci-dessous
	et les paramètres de la transmission à travers le pointeur static *lora_para_pt ci-dessus
    */
	
	SPI_NSS = NSS_Pin;			 // Pin affecté à l'ESCLAVE ACTIVE à l'ETAT BAS
	RF_NRESET = NRESET_Pin;		 // Pin permettant le RESET 	
	RF_BUSY = BUSY_Pin;			 // Pin indiquant si Module Lora occupé ou non
	RF_DIO1 = DIO1_Pin;			 // Pin affecté pour les interruption provenant du module LORA
	
	lora_para_pt->rf_freq;       // Fréquence émission
	lora_para_pt->tx_power;      // Puissance émission 
	lora_para_pt->lora_sf;		 // Spread Factor de la modulation
	lora_para_pt->band_width;	 // Bande defréquence allouer 		
	lora_para_pt->code_rate;     // Coding Rate CR
	lora_para_pt->payload_size;	 // taille du payload	
}

void SX1280::SX1280_Config(void)
{
	/*
	Pour l'Initialisation 
    Cette fonction sert à configuer La transmission Lora avec laquelle on veut opérer 
    */
 

	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	uint8_t size_temp;
	
	rf_freq_temp = lora_para_pt->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt->code_rate;  // Coding Rate CR
	size_temp = lora_para_pt->payload_size;  // taille du payload
	
	SetRegulatorMode(USE_LDO);     // Fonctionnement en mode LDO
	SetStandby(STDBY_RC);   //  0:STDBY_RC; 1:STDBY_XOSC
	SetPacketType(PACKET_TYPE_LORA);    // On met la transmission en Mode Lora à travers la fonction SetPacketType
	
	SetModulationParams(sf_temp,bw_temp,cr_temp);
	AfterSetModulationParams(sf_temp);
	SetPacketParams(size_temp);  //PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ
	SetLNAGainSetting(LNA_LOW_POWER_MODE);
    SetRfFrequency( rf_freq_temp );  //La commande SetRfFrequency() est utilisée pour définir la fréquence de transmission(porteuse).
    SetTxParams(power_temp, RADIO_RAMP_20_US );
	
	SetBufferBaseAddress( 0x00, 0x00 );     // Adresse stockage donnée à recevoir et à transmettre 
}					//TxBuffer,RxBuffer


void SX1280::SX1280_Config_Ranging_MASTER(void)
{
	/*
	Pour l'Initialisation 
    Cette fonction sert à configuer le RANGING avec laquelle on veut opérer 
    */
 

	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	uint8_t size_temp;
	
	rf_freq_temp = lora_para_pt->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt->code_rate;  // Coding Rate CR
	size_temp = lora_para_pt->payload_size;  // taille du payload
	
	SetRegulatorMode(USE_LDO);     // Fonctionnement en mode LDO
	SetStandby(STDBY_RC);   //  0:STDBY_RC; 1:STDBY_XOSC
	SetPacketType(PACKET_TYPE_RANGING);    // On met la transmission en Mode Lora à travers la fonction SetPacketType
	
	SetModulationParams(sf_temp,bw_temp,cr_temp);
	AfterSetModulationParams(sf_temp);
	
	SetPacketParams(size_temp);  //PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ
	//SetLNAGainSetting(LNA_LOW_POWER_MODE);
	SetLNAGainSetting(LNA_HIGH_SENSITIVITY_MODE);
    SetRfFrequency( rf_freq_temp );  //La commande SetRfFrequency() est utilisée pour définir la fréquence de transmission(porteuse).
    SetTxParams(power_temp, RADIO_RAMP_20_US );
	
	//SetRangingIdLength()
	SetRangingIdLength(RANGING_IDCHECK_LENGTH_32_BITS);
	SetRangingRequestAddress(30);
	SetDioIrqParams(IRQ_RANGING_MASTER_RESULT_VALID | IRQ_RANGING_MASTER_RESULT_TIMEOUT);
	//SetDioIrqParams(IRQ_RANGING_MASTER_RESULT_VALID);
	Calibration(bw_temp,sf_temp);
	SetRangingRole(RADIO_RANGING_ROLE_MASTER);
	//SetDeviceRangingAddress(30);

	SetBufferBaseAddress( 0x00, 0x00 );     // Adresse stockage donnée à recevoir et à transmettre 
}					//TxBuffer,RxBuffer





void SX1280::StartRanging_Master(void)
{
	uint8_t tx_buf[5] = "MASTE";

uint16_t tx_cnt = 0;
uint8_t rx_buf[5]={};
	TxPacket(tx_buf,5);
	WaitForIRQ_RangingDone_Master();

}					









void SX1280::SX1280_Config_Ranging_SLAVE(void)
{
	/*
	Pour l'Initialisation 
    Cette fonction sert à configuer le RANGING avec laquelle on veut opérer 
    */
 

	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	uint8_t size_temp;
	
	rf_freq_temp = lora_para_pt->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt->code_rate;  // Coding Rate CR
	size_temp = lora_para_pt->payload_size;  // taille du payload
	          
	
	SetRegulatorMode(USE_LDO);     // Fonctionnement en mode LDO
	SetStandby(STDBY_RC);   //  0:STDBY_RC; 1:STDBY_XOSC
	SetPacketType(PACKET_TYPE_RANGING);    // On met la transmission en Mode Lora à travers la fonction SetPacketType
	
	SetModulationParams(sf_temp,bw_temp,cr_temp);
	AfterSetModulationParams(sf_temp);
	
	SetPacketParams(size_temp);  //PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ
    SetRfFrequency( rf_freq_temp );  //La commande SetRfFrequency() est utilisée pour définir la fréquence de transmission(porteuse).
    SetTxParams(power_temp, RADIO_RAMP_20_US );
	
	//SetRangingRequestAddress(30);
	SetRangingIdLength(RANGING_IDCHECK_LENGTH_32_BITS);
	SetDeviceRangingAddress(30);
	SetDioIrqParams(IRQ_RANGING_SLAVE_REQUEST_DISCARDED | IRQ_RANGING_SLAVE_RESPONSE_DONE);
	Calibration(bw_temp,sf_temp);
	SetRangingRole(RADIO_RANGING_ROLE_SLAVE);

	SetBufferBaseAddress( 0x00, 0x00 );     // Adresse stockage donnée à recevoir et à transmettre 
}					//TxBuffer,RxBuffer

void SX1280::Calibration(uint8_t BW,uint8_t SF)
{
	if(BW == LORA_BW_0400){
                lora_para_pt->RngCalib = RNG_CALIB_0400[ ( SF >> 4 ) - 5 ];
                lora_para_pt->RngFeiFactor = ( double )RNG_FGRAD_0400[ ( SF >> 4 ) - 5 ];
                //Eeprom.EepromData.DemoSettings.RngReqDelay  = RNG_TIMER_MS >> ( 0 + 10 - ( SF >> 4 ) );
	}
	else if(BW == LORA_BW_0800){
				
                lora_para_pt->RngCalib = RNG_CALIB_0800[ ( SF >> 4 ) - 5 ];
                lora_para_pt->RngFeiFactor = ( double )RNG_FGRAD_0800[ ( SF >> 4 ) - 5 ];
               // Eeprom.EepromData.DemoSettings.RngReqDelay  = RNG_TIMER_MS >> ( 1 + 10 - ( SF >> 4 ) );
	}       

    else if(BW == LORA_BW_1600){
                lora_para_pt->RngCalib = RNG_CALIB_1600[ ( SF >> 4 ) - 5 ];
                lora_para_pt->RngFeiFactor = ( double )RNG_FGRAD_1600[ ( SF >> 4 ) - 5 ];
               // Eeprom.EepromData.DemoSettings.RngReqDelay  = RNG_TIMER_MS >> ( 2 + 10 - ( SF >> 4 ) );
              
        }
		uint16_t cal = lora_para_pt->RngCalib;
		SetRangingCalibration(cal);
		
        //Radio.SetPollingMode( );
        //Radio.SetLNAGainSetting(LNA_LOW_POWER_MODE);
	
}



void SX1280::Affiche_BW(int bw_hexa)
{      switch(bw_hexa){
        case 10:
        Serial.println("1625 kHz");
        break;
        case 24:
        Serial.println("812 kHz");
        break;
        case 38:
        Serial.println("406 kHz");
        break;
        case 52:
        Serial.println("203 kHz");
        break;
        
        }
}

void SX1280::RECONFIG(loRa_Para_t *lp_pt)
{
	/*
    Cette fonction permet l'initialisation du module Lora*/
	lora_para_pt = lp_pt; 
	/*
    Cette fonction sert à configuer La transmission Lora avec laquelle on veut opérer 
    */
	/*!!!!!!!!!!!! A UTILISER POUR TRANSMETTRE AVEC UNE MODULATION LORA DIFFERENTE !!!!!!!!!!!!!!!!
	 SF Different, ... 
	*/ 

	uint32_t rf_freq_temp;
	int8_t power_temp;
	uint8_t sf_temp;
	uint8_t bw_temp;
	uint8_t cr_temp;
	uint8_t size_temp;
	
	rf_freq_temp = lora_para_pt->rf_freq; // Fréquence émission/reception
	power_temp = lora_para_pt->tx_power;  // Puissance émission 
	sf_temp = lora_para_pt->lora_sf;   // Spread Factor de la modulation
	bw_temp = lora_para_pt->band_width;  // Bande defréquence allouer
	cr_temp = lora_para_pt->code_rate;  // Coding Rate CR
	size_temp = lora_para_pt->payload_size;  // taille du payload
	
	SetStandby(STDBY_RC);   //  0:STDBY_RC; 1:STDBY_XOSC
	//SetPacketType(PACKET_TYPE_LORA);    // On met la transmission en Mode Lora à travers la fonction SetPacketType
	
	SetModulationParams(sf_temp,bw_temp,cr_temp);
	AfterSetModulationParams(sf_temp);

    //SetRfFrequency( rf_freq_temp );  //La commande SetRfFrequency() est utilisée pour définir la fréquence de transmission(porteuse).
    //SetTxParams(power_temp, RADIO_RAMP_20_US );
	
	//SetPacketParams(size_temp);  //PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ
	//SetBufferBaseAddress( 0x00, 0x00 );     // Adresse stockage donnée à recevoir et à transmettre 
}					//TxBuffer,RxBuffer



void SX1280::SPI_Init(void)
{
	SPI.begin();
	
	// AFFECTATION et INITIALISATION pin ESCLAVE
	pinMode(SPI_NSS, OUTPUT);       // Définition de la pin servant à selctionner l'esclave 
	digitalWrite(SPI_NSS, HIGH);	// mise à l'ETAT HAUT de la pin car active à l'ETAT BAS

	// dépend du module LORA 
	SPI.setBitOrder(MSBFIRST);		// MSB first Selon le module LORA 
	
	// too fast may cause error
	SPI.setClockDivider(SPI_CLOCK_DIV16);  
	SPI.setDataMode(SPI_MODE0);     // SPI_MODE0 Niveau Logique 0 de SCLK au repos 
								    // FRONT DESCENDANT pour lire/modifier la donnée
	
}

bool SX1280::Init(loRa_Para_t *lp_pt)
{ 	/*
    Cette fonction permet l'initialisation du module Lora*/
	lora_para_pt = lp_pt;   // affectation des paramètre pour la config de la transmission LORA
	
	Pin_Init();				// Initialisation Des Pins
	SPI_Init();				// Configuration Liaison SPI
	
	Reset_SX1280();	// RESET Module LoRa 
	SX1280_Config();// RF parameter,frequency,data rate etc

	return true;
}


bool SX1280::Init_Ranging_Master(loRa_Para_t *lp_pt)
{ 	/*
    Cette fonction permet l'initialisation du module Lora*/
	lora_para_pt = lp_pt;   // affectation des paramètre pour la config de la transmission LORA
	
	Pin_Init();				// Initialisation Des Pins
	SPI_Init();				// Configuration Liaison SPI
	
	Reset_SX1280();	// RESET Module LoRa 
	SX1280_Config_Ranging_MASTER();// RF parameter,frequency,data rate etc

	return true;
}

bool SX1280::Init_Ranging_Slave(loRa_Para_t *lp_pt)
{ 	/*
    Cette fonction permet l'initialisation du module Lora*/
	lora_para_pt = lp_pt;   // affectation des paramètre pour la config de la transmission LORA
	
	Pin_Init();				// Initialisation Des Pins
	SPI_Init();				// Configuration Liaison SPI
	
	Reset_SX1280();	// RESET Module LoRa 
	SX1280_Config_Ranging_SLAVE();// RF parameter,frequency,data rate etc

	return true;
}


void SX1280::Pin_Init(void)
{
	/*
    Cette fonction permet l'AFFECTATION PHYSIQUE DES PIN 
    */
	pinMode(SPI_NSS, OUTPUT);
	pinMode(RF_NRESET, OUTPUT);       // Pin permettant RESET du module Lora
	digitalWrite(RF_NRESET, LOW);	  // Active à l'ETAT BAS 
	
	pinMode(RF_BUSY, INPUT);          // Pin indiquant si module occupé ou non ETAT BAS Ok pour recevoir nouvelle commande
	pinMode(RF_DIO1, INPUT);		  // Pin indiquant si interruption provenant du module Lora	
}

void SX1280::Reset_SX1280(void)
{   /* 
    Cette fonction sert à RESET le module Lora
*/
	delay(20);
	digitalWrite(RF_NRESET, LOW);	// RESET Active à l'ETAT BAS 
	delay(50);		//more thena 100us, delay 2ms
	digitalWrite(RF_NRESET, HIGH);	
	delay(20);		
}

uint8_t SX1280::spi_rw(uint8_t value_w) 
{
	/* 
    Cette fonction sert à transmettre/récupérer les données à travers la liaison SPI établie entre
	L'arduino et le Module LORA
	*/
	uint8_t value_r;
	
	value_r = SPI.transfer(value_w);   // Lorsqu'on envoie quelque chose en SPI on 
									   // reçoit dans le même temps quelque chose	
	
	return (value_r);	
}


void SX1280::CheckBusy(void)
{
    /*
    Fonction permettant de verifier et temporiser si le module LORA est occupé ou non
    */
	uint8_t busy_timeout_cnt;								
		
	busy_timeout_cnt = 0;
	//int tour =0;
	while(digitalRead(RF_BUSY))
	{
		delay(10);
		busy_timeout_cnt++;
		if(busy_timeout_cnt>200)	//TODO		
		{
			//TODO 
			//Reset_SX1280();		  // RESET Module LORA RF
			//SX1280_Config();      // Config du module LORA 
			//Serial.println("La broche Busy est à 1\n");
            //add a flag here, and add some process to reset the module in the main().
			break;		
		}

	}
}

void SX1280::WriteCommand(uint8_t Opcode, uint8_t *buffer, uint16_t size )
{
    /*
    Fonction qui permet l'écriture/envoi de données voulu au module LORA
    */
	uint8_t i;
	
	CheckBusy();
	
	SPI_NSS_LOW();    // Mise à l' ETAT BAS de l'esclave pour débuter la transmission
	spi_rw(Opcode);   // On met le code d'opération permettant d'accéder au registre voulu en SPI
	for(i=0;i<size;i++)  // On fait une boucle avec le nombre d'itératio correspondant au nombre d'octet à transmettre
	{					 // dans le registre
		spi_rw(buffer[i]);   
	}
	SPI_NSS_HIGH();   // Mise à l'ETAT HAUT de la pin de l'esclave car transmission SPI fini
	
	if( Opcode != RADIO_SET_SLEEP )
    {
        CheckBusy();
    }
}
void SX1280::ReadCommand( uint8_t Opcode, uint8_t *buffer, uint16_t size )
{
    /*
    Fonction servant à lire/récuperer les données provenant du module LORA 
    */
    uint8_t i;
	
	CheckBusy(); // On Verifie que le module LORA ne fait rien
    SPI_NSS_LOW(); // Mise à l' ETAT BAS de l'esclave pour débuter la transmission
	
	spi_rw(Opcode);		// On met le code  permettant d'accéder au registre voulu en SPI
	spi_rw(0xFF);		
	
	for( i = 0; i < size; i++ )// On fait une boucle avec le nombre d'itération correspondant au nombre d'octet à recevoir
    {							// tout en envoyant des octets sinon impossible de récupérer les datas 
		*(buffer+i) = spi_rw(0xFF);	  // propre à la liaison SPI
    }
	
    SPI_NSS_HIGH();			// Mise à l'ETAT HAUT de la pin de l'esclave car transmission SPI fini
    CheckBusy();
}


void SX1280::WriteBuffer(uint8_t offset, uint8_t *data, uint8_t length)
{
    uint16_t i;
	// ************** page 75 **************
	/*
	Cette fonction est utilisée pour écrire le payload à transmettre. L'adresse est auto-incrémentée, lorsque l'adresse
dépasse 255, il revient à 0 en raison de la nature circulaire du tampon de données. L'adresse commence à partir de l'offset donné comme
paramètre de la fonction
	*/
	
	CheckBusy();      // On Verifie que le module LORA ne fait rien
    SPI_NSS_LOW();    // Mise à l' ETAT BAS de l'esclave pour débuter la transmission SPI

	spi_rw(RADIO_WRITE_BUFFER);
		// (0x1A)
	spi_rw(offset);  // offset est l'adresse de départ pour l'écriture dans le buffer
	
	for(i=0;i<length;i++)
	{
		spi_rw(data[i]);
	}
	
    SPI_NSS_HIGH();
    CheckBusy();
}



//0:STDBY_RC; 1:STDBY_XOSC
void SX1280::SetStandby(uint8_t StdbyConfig)
{
	/*
     La commande SetStandby() ayant 0x80 pour OpCode, est utilisée pour régler l'appareil en mode STDBY_RC ou STDBY_XOSC
	 qui ont des niveaux intermédiaires de consommation d'énergie. Dans ce mode Veille, 
	 le module LORA peut être configurer pour les futures opérations RF.
     Après la mise sous tension ou l'application d'une réinitialisation, le réveil NSS ou RTC, 
     l'émetteur-récepteur entrera en mode STDBY_RC fonctionnant avec une horloge RC de 13 MHz.
*/

	uint8_t Opcode;
	
	Opcode = 0x80;	//
	
	CheckBusy();
	SPI_NSS_LOW();
	spi_rw(Opcode);
	spi_rw(StdbyConfig);
	SPI_NSS_HIGH();
}

/************************************************************************************
periodBase  Time-out step
  0x00        15.625 us
  0x01        62.5 us
  0x02        1 ms
  0x03        4 ms
  
periodBaseCount
   0x0000         No time-out, Tx Single mode
   Others 		  Time-out active,Time-out duration = periodBase * periodBaseCount
***********************************************************************************/

void SX1280::SetTx(uint8_t periodBase, uint16_t periodBaseCount)
{ //********** PAGE 79 DATASHEET **********
/*
Cette fonction met le Module Lora en mode transmission à laide de l'OpCode 0x83 SetTx() 
Il faut effacer l'état IRQ avant d'utiliser cette commande
*/
	uint8_t buf[3];
	
    buf[0] = periodBase;  // unité d'un pas incrémentation temporelle
	// periodBcount contient le nombre de pas souhaité afin d'établir le temps avant d'exectuter 
	// Le Timeout
	// Timeout =(periodBase*periodBaseCount)
    buf[1] = ( uint8_t )( ( periodBaseCount >> 8 ) & 0x00FF ); // Décalage de 8 bits sur la droite + Mask car MSBFIRST
    buf[2] = ( uint8_t )( periodBaseCount & 0x00FF );  // Mask
	
	WriteCommand( RADIO_SET_TX, buf, 3 );
}			//(0x83,adresse data à envoyer,nombre octet à écrire)
			// 2 IRQ(Interruption possibles) soit Tx_done(donc transmission OK) 
			// soit de timeout ça veut dire que la transmission n'est pas ok 

/************************************************************************************
periodBase  Time-out step
  0x00        15.625 us
  0x01        62.5 us
  0x02        1 ms
  0x03        4 ms
  
periodBaseCount
   0x0000         No time-out. Rx Single mode
   0xFFFF		  Rx Continuous mode
   Others 		  Time-out active,Time-out duration = periodBase * periodBaseCount
***********************************************************************************/
void SX1280::SetRx(uint8_t periodBase, uint16_t periodBaseCount)
{/*
Cette fonction met l'appareil en mode Récepteur. à l'aide de la commande SetRx() qui a pour Opcode 0x82 
L'état IRQ doit être effacé avant d'utiliser cette commande,
*/
	uint8_t buf[3];
	
	buf[0] = periodBase;// unité d'un pas incrémentation temporelle
	// periodBcount contient le nombre de pas souhaité afin d'établir le temps avant d'exectuter 
	// Le Timeout
	// Timeout =(periodBase*periodBaseCount)
    buf[1] = ( uint8_t )( ( periodBaseCount >> 8 ) & 0x00FF ); // Décalage de 8 bits sur la droite + Mask car MSBFIRST
    buf[2] = ( uint8_t )( periodBaseCount & 0x00FF );  // Mask
	
	WriteCommand( RADIO_SET_RX, buf, 3 );
}			// (0x82,adresse data à envoyer,nombre octet à écrire)



/******************************************************
	packetType			Valeur			Modem mode of operation
 PACKET_TYPE_GFSK 		0x00[default] 		GFSK mode
 PACKET_TYPE_LORA 		0x01 				LoRa mode
 PACKET_TYPE_RANGING 	0x02 				Ranging Engine mode
 PACKET_TYPE_FLRC 		0x03 				FLRC mode
 PACKET_TYPE_BLE 		0x04 				BLE mode
******************************************************/

void SX1280::SetPacketType( uint8_t packetType )
{ 
    // ********************** Page 85-86 ***********************

/*!!!!!!!!!!!!!!!!!!!!!!!	
	La commande SetPacketType() doit être la première d'une séquence de configuration radio.	
									!!!!!!!!!!!!!!!!!!!!!!!*/
	/*
La commande SetPacketType() définit la trame radio de l'émetteur-récepteur 
parmi un choix de 5 types de paquets différents ci-dessus. 
*/
    WriteCommand( RADIO_SET_PACKETTYPE,&packetType, 1 );
				// (0x8A  , adresse où se trouve l'information du type de paquet, nombre octet à transmette)

								
}

uint8_t SX1280::GetPacketType(void)
{
	// ********************** Page 86 ***********************

	/*
    Cette fonction renvoie le type de paquet de fonctionnement actuel de la radio.
	à l'aide de la commande GetPacketType() qui a pour Opcode 0x03
	*/
	uint8_t Opcode;
	uint8_t Status;
	uint8_t packetType;
	
	CheckBusy();
	Opcode = RADIO_GET_PACKETTYPE; //(0X03)
	
	SPI_NSS_LOW();
	spi_rw(Opcode);
	Status = spi_rw(0xFF);
	packetType = spi_rw(0xFF);
	SPI_NSS_HIGH();
	
	return packetType;
}

void SX1280::SetRfFrequency( uint32_t frequency )
{ 
	// ********************** Page 87 ***********************
 
	/*
	Cette fonction sert à définir la fréquence d'émission/réception.
	à l'aide de la commande SetRfFrequency() qui a pour Opcode 0x86
	*/
	
    uint8_t buf[3];
    uint32_t freq = 0;  // Valeur mise sur 24 bit 
// ********** Définir la fréquence de transmission 11-45 page 87 et 3. page 130 datasheet **********
	// Frf est la fréquence ICI Paramètre "frequency" que nous voulons comme porteuse
	// freq est la rfFrequency de la datasheet à implémenter dans le module LORA
	// ********** Page 87 datasheet ********** FREQ_STEP = 52e6 / (2^18) Hz 
	// ********** Page 30 datasheet ********** rfFrequency=Frf*(2^18)/52e6 donc rfFrequency=Frf/FREQ_STER
    freq = ( uint32_t )( ( double )frequency / ( double )FREQ_STEP );
    buf[0] = ( uint8_t )( ( freq >> 16 ) & 0xFF );    // Décalage de 16 bit avec mask car MSBFIRST
    buf[1] = ( uint8_t )( ( freq >> 8 ) & 0xFF );	  // Décalage de 8 bit avec mask
    buf[2] = ( uint8_t )( freq & 0xFF );			  // Mask
    WriteCommand( RADIO_SET_RFFREQUENCY, buf, 3 );
}			  //(0x86,adresse data,nombre octet)

void SX1280::SetTxParams( int8_t power, uint8_t rampTime )
{
		// ********************** Page 87-88 ***********************

	/*
	Cette fonction sert à définir la puissance de sortie Tx à l'aide du paramètre power et le ramptime Tx. La commande est disponible pour tous les Types de Paquets.
	*/
    uint8_t buf[2];
	
	// ********** page 87/88 datasheet **********
    // La puissance à envoyer en SPI est entre [0..31] 
    // et la sortie de puissance est entre [-18..13]dBm
	// PoutMin = -18dBm -> Power = 0
	// PoutMax = 13dBm -> Power = 31
    buf[0] = power + 18;     // Donc +18 pour être dans le bon ensemble défini pour le Module LORA [0..31]
	//buf[0] = 31;     // Donc +18 pour être dans le bon ensemble défini pour le Module LORA [0..31]
    buf[1] = ( uint8_t )rampTime;
    WriteCommand( RADIO_SET_TXPARAMS, buf, 2 );
}		      //(0x8E,adresse data,nombre octet)


void SX1280::SetBufferBaseAddress( uint8_t txBaseAddress, uint8_t rxBaseAddress )
{	/* 
    Cette fonction fixe l'adresse de base pour l'opération de traitement des paquets en mode Tx et Rx
	pour tous les types de paquets 
    */
	uint8_t buf[2];

    buf[0] = txBaseAddress;
    buf[1] = rxBaseAddress;
    WriteCommand( RADIO_SET_BUFFERBASEADDRESS, buf, 2 );
}			//	(0x8F,donnée à transmette, nombre octet)

void SX1280::SetModulationParams(uint8_t sf, uint8_t bw, uint8_t cr)
{	// ********** page 89/90 datasheet **********
	/* 
	Cette fonction permet d'implementer les paramétres de la Modulation Radio LORA SF(Spreading Factor),
	BW(Bande Utile), CR (Coding Rate) à l'aide de la commande SetModulationParams() qui a pour 
	OpCode 0x8B
	*/
    uint8_t buf[3];
		
    //Paramètres utilsés dans PACKET_TYPE_LORA ou PACKET_TYPE_RANGING		
    buf[0] = sf;      //SPREADING FACTOR   
    buf[1] = bw;	  // BANDWIDTH 
    buf[2] = cr;	  // CODING RATE
    WriteCommand( RADIO_SET_MODULATIONPARAMS, buf, 3 );
}			//	(0x8B, adresse data, nombre octet à écrire)


void SX1280::AfterSetModulationParams(uint8_t sf){
		/*Page 131 indiqué d'implementer selon le spreading factor des valeur dans le registre à l'adresse 0x925
		En utilisant la commande writeregister
	*/
			
	if(sf==LORA_SF5||sf== LORA_SF6)
	{
		WriteRegister(0x0925,0x1E);}
	else if (sf==LORA_SF7||sf== LORA_SF8)
	{
		WriteRegister(0x0925,0x37);}
	else if(sf==LORA_SF9||sf== LORA_SF10||sf== LORA_SF11||sf== LORA_SF12)
	{
		WriteRegister(0x0925,0x32);}

	WriteRegister(0x093C,0x1);
	
}

void SX1280::SetPacketParams(uint8_t payload_len)
{    // ********** page 90/91 datasheet **********
	/*
    Cette fonction sert à définir les paramètres du block de gestion des paquets à envoyer/recevoir à 
	l'aide de la commande Set de l'Opcode 0x8C.
	*/
    uint8_t buf[7];

    //Paramètre utilisé dans PACKET_TYPE_LORA ou PACKET_TYPE_RANGING	
	buf[0] = 12;	//PreambleLength;   12 symboles est la taille recommandée en page 132 au-dessus table 14-50 
	// Valeur 12 exposant=0 lenmantisse=12 donc taille du preambule est 12
	buf[1] = LORA_PACKET_VARIABLE_LENGTH; //(0x00)	//HeaderType; ********** page 132 ********** Tableau 14-51
	buf[2] = payload_len;	//PayloadLength;     ********** page 132 ********** Tableau 14-52
	buf[3] = LORA_CRC_ON;	//CrcMode; ********** page 132 ********** Tableau 14-53
	buf[4] = LORA_IQ_NORMAL;	//InvertIQ; ********** page 133 ********** Tableau 14-54
	buf[5] = NULL;
	buf[6] = NULL;

    WriteCommand( RADIO_SET_PACKETPARAMS, buf, 7 );
}			   //(0x8C,adresse data à mettre registre, nombre octet à transmettre)	



void SX1280::GetPacketStatus(int8_t *RssiPkt,int8_t *SnrPkt)
{  // *************  voir page 93  *************
	/*
    Cette fonction basé sur la commande GetPacketStatus() command permet de récupérer des informations(Rssi et SNR) sur le dernier paquet reçu
	à l'aide de l'OpCode 0x1D
	*/
    uint8_t status[5];
    ReadCommand( RADIO_GET_PACKETSTATUS, status, 5 );
			//	(0x1D, endroit de stockage data recup, nombre octets à récupérer)
    //Pour PACKET_TYPE_LORA ou PACKET_TYPE_RANGING
    // Car il n'y a que 2 informations récupérable qui sont le RSSI et le SNR
	*RssiPkt = -status[0] / 2; //************* Explication page 93 Table 11-66 *************
	//Serial.println(*RssiPkt);
    if( status[1] < 128 ) 
	{*SnrPkt = status[1] / 4 ; 
		//Serial.println(*SnrPkt);
	}
	else
	{	*SnrPkt = ( status[1] - 256 ) / 4;
		//Serial.println(*SnrPkt);
		//*RssiPkt-=*SnrPkt;
		}
}	
	

int8_t SX1280::GetRssiInst( void )
{	// *************  voir page 95  *************
    /*
    Cette fonction permet de récupérer le RSSI instanée qui provient du dernier paquet reçu
    */
    uint8_t raw = 0;

    ReadCommand( RADIO_GET_RSSIINST, &raw, 1 );
			//  (0x1F , adresse où récupérer la donnée, nombre octet à récup)

    return ( int8_t )( -raw / 2 );
}

void SX1280::SetDioIrqParams(uint16_t irq)
{	//********** page 86 ********** Tableau 11-74
/* 
Fonction servant à activer les Interruptions 
*/
    uint8_t buf[8];
	uint16_t irqMask;
	uint16_t dio1Mask; // Nous utilisons qu'un seul registre pour l'ensemble des interruptions
	uint16_t dio2Mask;
	uint16_t dio3Mask;
	
	irqMask = irq;
	dio1Mask = irq;
	dio2Mask = 0;
	dio3Mask = 0;
	
    buf[0] = ( uint8_t )( irqMask >> 8 );
    buf[1] = ( uint8_t )( irqMask & 0xFF );
    buf[2] = ( uint8_t )( dio1Mask >> 8 );
    buf[3] = ( uint8_t )( dio1Mask & 0xFF );
    buf[4] = ( uint8_t )( dio2Mask >> 8 );
    buf[5] = ( uint8_t )( dio2Mask & 0xFF );
    buf[6] = ( uint8_t )( dio3Mask >> 8 );
    buf[7] = ( uint8_t )( dio3Mask & 0xFF );
	
    WriteCommand( RADIO_SET_DIOIRQPARAMS, buf, 8 );
}

uint16_t SX1280::GetIrqStatus( void )
{		// ********** page 97 datasheet **********
	 /*
     Cette fonction sert à récuperer le status des interruptions
     */
    uint8_t irqStatus[2];  // tableau permettant de récupérer en 2 fois car 16 octet à récupérer
	uint16_t IrqStatus;    // Variable servant à contenir le IRQ statut
	
    ReadCommand( RADIO_GET_IRQSTATUS, irqStatus, 2 );
				//(0x15, pointeur data,nombre octet)  
	
	IrqStatus = irqStatus[0];
	IrqStatus = IrqStatus<<8;      // décalage 8 bit sur la gauche car on reçoit en premier MSB 
	IrqStatus = IrqStatus|irqStatus[1]; // Status IRQ sur 16 bit
	
    return IrqStatus;
}

void SX1280::ClearIrqStatus( uint16_t irq )
{    // ********** page 97 datasheet ********** Tableau 11-78
	/* 
     Cette fonction sert à mettre les drapeau d'interruption à 0 
     */
    uint8_t buf[2];

    buf[0] = ( uint8_t )( irq >> 8 );
    buf[1] = ( uint8_t )( irq & 0xFF );
    WriteCommand( RADIO_CLR_IRQSTATUS, buf, 2 );
}			//(0x97, adresse data à implémenter dans registre, nombre d'octet à implémenter)	

void SX1280::SetRegulatorMode( uint8_t mode )
{		// ********** page 143 datasheet **********
/* 
Cette fonction à travers la commande qui a pour OpCode 0x96 permet à l'utilisateur 
pour spécifier si DC-DC ou LDO est utilisé pour la régulation de puissance. Par défaut, le LDO est activé. 
*/

    WriteCommand( RADIO_SET_REGULATORMODE, &mode, 1 );
}               // (0x96 , Mode LDO ou DC-DC, 1 octet à transmettre)


void SX1280::TxPacket(uint8_t *payload,uint8_t size)
{
    /*
    Cette fonction sert à mettre le Module Lora en Mode Transmission et à transmettre les données voulues
    */
	SetStandby(STDBY_RC);//0:STDBY_RC; 1:STDBY_XOSC
	SetBufferBaseAddress(0,0);//(TX_base_addr,RX_base_addr)

	WriteBuffer(0,payload,size);//(offset,*data,length)
	SetPacketParams(size);//PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ

	SetDioIrqParams(IRQ_TX_DONE);//Activation de l'interruption TX_DONE
	
	SetTx(PERIOBASE_15_US,0);//timeout = 0
	//WaitForIRQ_TxDone();
	//Wait for the IRQ TxDone or Timeout(implement in another function)
}


void SX1280::TxPacket_ranging(uint8_t *payload,uint8_t size)
{
    /*
    Cette fonction sert à mettre le Module Lora en Mode Transmission et à transmettre les données voulues
    */
	SetStandby(STDBY_RC);//0:STDBY_RC; 1:STDBY_XOSC
	SetBufferBaseAddress(0,0);//(TX_base_addr,RX_base_addr)

	WriteBuffer(0,payload,size);//(offset,*data,length)
	SetPacketParams(size);//PreambleLength;HeaderType;PayloadLength;CRCType;InvertIQ

	//SetDioIrqParams(IRQ_TX_DONE);//Activation de l'interruption TX_DONE
	
	SetTx(PERIOBASE_15_US,0);//timeout = 0
	//WaitForIRQ_TxDone();
	//Wait for the IRQ TxDone or Timeout(implement in another function)
}

uint8_t SX1280::WaitForIRQ_TxDone(void)
{		/* 
Cette Fonction permet de s'assurer que la Transmission a bien été réalisée
*/
	int time_out;
	
	time_out = 0;
	while(!digitalRead(RF_DIO1)) 
	{
		time_out++;
		delay(1); // attente 10 ms
		//Serial.println("Attente envoi du message\n");
		//Serial.println("Attente envoi du message\n");
		if(time_out > 1000)	//if timeout , reset the the chip
		{	Serial.println("Attente envoi du message\n");
			/*ClearIrqStatus(IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
			SetStandby(STDBY_RC); // 0:STDBY_RC; 1:STDBY_XOSC
			Reset_SX1280();		  // RESET Module LORA RF
			SX1280_Config();      // Config du module LORA 
			Serial.println("Attente envoi du message\n");
			//Serial.println(time_out);*/
			return 0;		
		}
		//Serial.println("Attente envoi du message\n");
	}
	
	//Irq_Status = GetIrqStatus();
	ClearIrqStatus(IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
    return 1;
    // Pour moi il faudrait rajouté un return 1
}
uint8_t SX1280::WaitForIRQ_TxDone_Ranging(void)
{		/* 
Cette Fonction permet de s'assurer que la Transmission a bien été réalisée
*/
	uint8_t time_out;
	
	time_out = 0;
	while(!digitalRead(RF_DIO1)) 
	{
		//time_out++;
		delay(1); // attente 10 ms
		if(time_out > 250)	//if timeout , reset the the chip
		{
			/*ClearIrqStatus(IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
			SetStandby(STDBY_RC); // 0:STDBY_RC; 1:STDBY_XOSC
			Reset_SX1280();		  // RESET Module LORA RF
			SX1280_Config();      // Config du module LORA 
			Serial.println("Attente envoi du message\n");
			//Serial.println(time_out);
			return 0;*/		
		}
		//Serial.println("Attente envoi du message\n");
	}
	
	//Irq_Status = GetIrqStatus();
	//ClearIrqStatus(IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
    //return 1;
    // Pour moi il faudrait rajouté un return 1
}

uint8_t SX1280::WaitForIRQ_RangingDone_Master(void)
{		/* 
Cette Fonction permet de s'assurer que la Transmission a bien été réalisée
*/
	uint8_t time_out;
	uint16_t Irq_Status;
	//WaitForIRQ_TxDone();
	//ClearIrqStatus(IRQ_TX_DONE);
	//RxInit_Ranging_Master();
	time_out = 0;
	SetDioIrqParams(0x0600);
	while(!digitalRead(RF_DIO1)) 
	{
		time_out++;
		delay(1); // attente 10 ms
		//Serial.println("JE SUIS LA");
		/*if(time_out > 250)	//if timeout , reset the the chip
		{
			//ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_VALID | IRQ_RANGING_MASTER_RESULT_TIMEOUT);//Effacement du drapeau RQ_TX_DONE
			//SetStandby(STDBY_RC); // 0:STDBY_RC; 1:STDBY_XOSC
			//Reset_SX1280();		  // RESET Module LORA RF
			//SX1280_Config();      // Config du module LORA 
			//Serial.println("Ranging échoué !!!\n");
			//Serial.println(time_out);
			return 0;		
		}*/
		//Serial.println("Attente envoi du message\n");
	}
	Irq_Status = GetIrqStatus();//read Irq Status
	
	if((Irq_Status&0x0200) == IRQ_RANGING_MASTER_RESULT_VALID) 
	{
	//Irq_Status = GetIrqStatus();
	Serial.println("RANGING OK");
	//ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
    	ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID);
	return 1;
	}
	else if((Irq_Status&0x0400) == IRQ_RANGING_MASTER_RESULT_TIMEOUT)
	{
		Serial.println("TIME OUT");
		//ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID|IRQ_TX_DONE);
			ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID);
		return 0;
	}
	
	//ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID|IRQ_TX_DONE);
	ClearIrqStatus(IRQ_RANGING_MASTER_RESULT_TIMEOUT|IRQ_RANGING_MASTER_RESULT_VALID);
	return 0;
    // Pour moi il faudrait rajouté un return 1
}
uint8_t SX1280::WaitForIRQ_RangingDone_Slave(void)
{		/* 
Cette Fonction permet de s'assurer que la Transmission a bien été réalisée
*/
	uint16_t Irq_Status;
	uint8_t time_out;

	RxInit_Ranging_Slave();
	
	while(!digitalRead(RF_DIO1)) 
	{
		//time_out++;
		//delay(1); // attente 10 ms
		//if(time_out > 250)	//if timeout , reset the the chip
		//{
			/*ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_DISCARDED | IRQ_RANGING_SLAVE_RESPONSE_DONE);//Effacement du drapeau RQ_TX_DONE
			SetStandby(STDBY_RC); // 0:STDBY_RC; 1:STDBY_XOSC
			Reset_SX1280();		  // RESET Module LORA RF
			SX1280_Config();      // Config du module LORA 
			Serial.println("Ranging échoué !!!\n");
			//Serial.println(time_out);
			return 0;	*/	
		//}
		//Serial.println("Attente envoi du message\n");
	}
		Irq_Status = GetIrqStatus();//read Irq Status
	
	if((Irq_Status&0x0200) == IRQ_RANGING_SLAVE_REQUEST_VALID) 
	{
		//TxPacket(tx_buf,5);
		//WaitForIRQ_TxDone_Ranging();
	//Irq_Status = GetIrqStatus();
	ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
	Serial.println("IRQ_RANGING_SLAVE_REQUEST_VALID\n");
    return 1;
	}
	else if((Irq_Status&0x0080) == IRQ_RANGING_SLAVE_RESPONSE_DONE){
		//Irq_Status = GetIrqStatus();
		//TxPacket(tx_buf,5);
		//WaitForIRQ_TxDone_Ranging();
		ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
		//WaitForIRQ_TxDone_Ranging();
		//Serial.println("IRQ_RANGING_SLAVE_RESPONSE_DONE\n");
	
    return 1;
	}
	else if((Irq_Status&0x0100) == IRQ_RANGING_SLAVE_REQUEST_DISCARDED)
	{
		ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
		Serial.println("IRQ_RANGING_SLAVE_REQUEST_DISCARDED\n");
		return 0;
	}
	ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);
	Serial.println("AUCUNE INTERRUPTION\n");
	

	return 0;
	
}

uint8_t SX1280::WaitForIRQ_RangingDone_Slave_NEW(uint32_t Delay_attente)
{		/* 
Cette Fonction permet de s'assurer que la Transmission a bien été réalisée
*/	
	uint16_t Irq_Status;
	uint8_t time_out;
	RxInit_Ranging_Slave();
	uint32_t debut_attente = millis();
	time_out = 0;
	while(!digitalRead(RF_DIO1)) 
	{
		if(millis()-debut_attente >= Delay_attente)
		{
			return 2;
		}
		//delay(1); // attente 1 ms

	}
		Irq_Status = GetIrqStatus();//read Irq Status
	
	/*if((Irq_Status&0x0200) == IRQ_RANGING_SLAVE_REQUEST_VALID) 
	{
	ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
	Serial.println("IRQ_RANGING_SLAVE_REQUEST_VALID\n");
    return 1;
	}
	else */if((Irq_Status&0x0080) == IRQ_RANGING_SLAVE_RESPONSE_DONE){
		ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
		//Serial.println("IRQ_RANGING_SLAVE_RESPONSE_DONE\n");
	
    return 1;
	}
	else if((Irq_Status&0x0100) == IRQ_RANGING_SLAVE_REQUEST_DISCARDED)
	{
		ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);//Effacement du drapeau RQ_TX_DONE
		Serial.println("IRQ_RANGING_SLAVE_REQUEST_DISCARDED\n");
		return 0;
	}
	ClearIrqStatus(IRQ_RANGING_SLAVE_REQUEST_VALID|IRQ_RANGING_SLAVE_RESPONSE_DONE|IRQ_RANGING_SLAVE_REQUEST_DISCARDED|IRQ_TX_DONE);
	Serial.println("AUCUNE INTERRUPTION\n");
	

	return 0;
	
}




void SX1280::RxBufferInit(uint8_t *rxpayload,uint16_t *rx_size)
{
	rxbuf_pt = rxpayload;
	rxcnt_pt = rx_size;
	//Adress_Payload_RX = rxpayload;
}

void SX1280::RxInit(void)
{/* 
Cette fonction sert à initialisé la position dans le buffer des données 
à recevoir et à transmettre, à activer l'interruption liée à la bonne réception de donnée,
et à fixer le temps de timeout si besoin
*/

	SetBufferBaseAddress(0,0);  //(TX_base_addr,RX_base_addr)
	//SetDioIrqParams(IRQ_RX_DONE);  //Autorisation Interruption RxDone
	SetDioIrqParams(0x0042);  //Autorisation Interruption RxDone et CRC
	SetRx(PERIOBASE_15_US,0); //timeout = 0
}

void SX1280::RxInit_Ranging_Slave(void)
{/* 
Cette fonction sert à initialisé la position dans le buffer des données 
à recevoir et à transmettre, à activer l'interruption liée à la bonne réception de donnée,
et à fixer le temps de timeout si besoin
*/

	SetBufferBaseAddress(0,0);  //(TX_base_addr,RX_base_addr)
	//SetDioIrqParams(IRQ_RX_DONE);  //Autorisation Interruption RxDone
	//SetDioIrqParams(0x0180);  //Autorisation Interruption RxDone et CRC
	SetRx(PERIOBASE_15_US,0xFFFF); //timeout = 0
}

void SX1280::RxInit_Ranging_Master(void)
{/* 
Cette fonction sert à initialisé la position dans le buffer des données 
à recevoir et à transmettre, à activer l'interruption liée à la bonne réception de donnée,
et à fixer le temps de timeout si besoin
*/

	//SetBufferBaseAddress(0,0);  //(TX_base_addr,RX_base_addr)
	//SetDioIrqParams(IRQ_RX_DONE);  //Autorisation Interruption RxDone
	SetDioIrqParams(0x0600);  //Autorisation Interruption RxDone et CRC
	//SetRx(PERIOBASE_15_US,0xFFFF); //timeout = 0
}



uint8_t SX1280::WaitForIRQ_RxDone(void)
{
	/*
	Cette fonction sert à effectuer toute la procédure lié à la réception de donnée du module
	*/
	uint16_t Irq_Status;
	uint8_t packet_size;
	uint8_t buf_offset;
	bool flag_rx=false;
	RxInit();
	
	//Serial.println("En Mode Rx\n");
	do{
				if(digitalRead(RF_DIO1))//if IRQ check
				{
					Irq_Status = GetIrqStatus();//read Irq Status
					if((Irq_Status&0x0002) == IRQ_RX_DONE)       // IRQ Status avec mask lié au RX_Done 
					{
						GetRxBufferStatus(&packet_size, &buf_offset);   //On récupère la taille du Payload et L'adresse du premier Octet reçu dans le RxBuffer
																		// Cette adresse est un offset relatif à l'emplacement du premier
																		// octet du buffer de données
						//rxbuf_pt = (uint8_t *) realloc(rxbuf_pt, packet_size * sizeof(uint8_t));
						//rxbuf_pt = (uint8_t *) malloc(packet_size * sizeof(uint8_t));
						ReadBuffer(buf_offset, rxbuf_pt, packet_size+1);   // buf_offset indique où est la donnée à lire dans le buffer du SX1280 
						*rxcnt_pt = packet_size; 
						if((Irq_Status&0x0040) == IRQ_CRC_ERROR)
						{
							Serial.println("ERREUR CRC");
							ClearIrqStatus(0x0042);
							return 0;}
						else{
							
							ClearIrqStatus(IRQ_RX_DONE);
						}
						//RxInit();
						return 1;
						flag_rx=true;
					}
					
				}		
		}while(!flag_rx);
	return 0;
}


uint8_t SX1280::WaitForIRQ_RxDone_GateWay(int Delai_Attente_Reponse)
{
	/*
	Cette fonction sert à effectuer toute la procédure lié à la réception de donnée du module
	*/
	uint16_t Irq_Status;
	uint8_t packet_size;
	uint8_t buf_offset;
	bool flag_rx=false;
	static uint32_t Debut_Attente_Reponse =0;
	Debut_Attente_Reponse = millis();
	RxInit();
	//Serial.println("En Mode Rx\n");
	do{
				if(digitalRead(RF_DIO1))//if IRQ check
				{
					Irq_Status = GetIrqStatus();//read Irq Status
					if((Irq_Status&0x0002) == IRQ_RX_DONE)       // IRQ Status avec mask lié au RX_Done 
					{
						GetRxBufferStatus(&packet_size, &buf_offset);   //On récupère la taille du Payload et L'adresse du premier Octet reçu dans le RxBuffer
																		// Cette adresse est un offset relatif à l'emplacement du premier
																		// octet du buffer de données
						ReadBuffer(buf_offset, rxbuf_pt, packet_size+1);   // buf_offset indique où est la donnée à lire dans le buffer du SX1280 
						*rxcnt_pt = packet_size; 
						if((Irq_Status&0x0040) == IRQ_CRC_ERROR)
						{
							Serial.println("ERREUR CRC");
							ClearIrqStatus(0x0042);
							return 0;}
						else{
							
							ClearIrqStatus(IRQ_RX_DONE);
						}
						//RxInit();
						return 1;
						flag_rx=true;
					}
					
				}		
		}while((!flag_rx) && (millis()-Debut_Attente_Reponse<=Delai_Attente_Reponse));
	return 0;
}




void SX1280::GetRxBufferStatus( uint8_t *payloadLength, uint8_t *rxStartBufferPointer )
{		/*
		Cette Fonction permet de récupérer la taille du Payload et l'adresse de départ de celui-ci
		à l'aide de la commande RADIO_GET_RXBUFFERSTATUS qui renvoie la longueur du dernier paquet reçu (payloadLengthRx) 
		et l'adresse du premier octet reçu(rxBufferOffset), il est applicable à tous les modems. L'adresse est un offset relatif au premier octet du Buffer.
*/
    uint8_t status[2];
				// *************  voir page 92  *************
    ReadCommand( RADIO_GET_RXBUFFERSTATUS, status, 2 );
				//(0x17,adresse reception data, nombre d'octet à recupérer)
    // Dans le cas LORA avec Fixed HEADER, Le payloadLength est obtenu en lisant
    // le registre REG_LR_PAYLOADLENGTH car dans ce cas GetRxBufferStatus retourne
	// toujours 0x00 pour le rxPayloadLength
	// *************  voir page 92 note en-dessous Table 11-62 ************
    if( ReadRegister( REG_LR_PACKETPARAMS ) >> 7 == 1 )  // si le bit 7 est à 1
						// Indique si le module LoRa utilise un header ou non  
						// header mode 0 = Header 
						//header mode 1 = No header
    {				 // (0x903) ************ Page 101 ************	
        *payloadLength = ReadRegister( REG_LR_PAYLOADLENGTH ); 
    }									//(0x901) ************ Page 101 ************	
	else
	{
		*payloadLength = status[0];  // Premier octet contenant le rxPayloadLength
	}
    *rxStartBufferPointer = status[1];  // Contient L'adresse du premier Octet reçu dans le RxBuffer
										// Cette adresse est un offset relatif à l'emplacement du premier
										// octet du buffer de données
}

void SX1280::ReadBuffer(uint8_t offset, uint8_t *data, uint8_t length)
{	// ******************** Page 76 ********************
/*
Cette fonction permet de lire (n-3) octets du payload reçues à partir de l'offset.
*/
    uint16_t i;
	
	CheckBusy();   // on s'assure que le module Lora ne fait rien avant d'entreprendre la lecture du buffer 
    SPI_NSS_LOW();  // Mise à l'ETAT BAS pour activer le dialoggue avec l'ESCLAVE 

	spi_rw(RADIO_READ_BUFFER);  // OP CODE 0x1B
	spi_rw(offset);
	spi_rw(0xFF);
	for(i=0;i<length;i++)  // Length Taille du Payload reçu
	{
		data[i]=spi_rw(0xFF);
	}
	
    SPI_NSS_HIGH();
    CheckBusy();
}


uint8_t SX1280::ReadRegister( uint16_t address )
{  /*
Cette fonction permet de lire l'état des registres si nécessaire
*/
    uint8_t data;

    ReadRegisters( address, &data, 1 );

    return data;
}


void SX1280::ReadRegisters( uint16_t address, uint8_t *buffer, uint16_t size )
{   /*

Cette fonction à l'aide de la commande ReadRegister() lit un bloc de données à partir d'une adresse donnée. L'adresse est automatiquement 
incrémentée après chaque octet. Le transfert de données SPI est décrit dans le Tableau 11-10 page 75 de la DATASHEET
Lors de l'utilisation de SPI, l'hôte doit envoyer un NOP(No Opération 0x00 ou 0xFF) après avoir envoyé les 2 octets d'adresse pour commencer 
à recevoir des octets de données sur le prochain NOP envoyé.

*/
    uint16_t i;
	uint8_t addr_l,addr_h;
	
	addr_h = address >> 8;  //Décalage de 8 bit sur la droite car addresse sur 16 bits
	addr_l = address & 0x00FF;
	
    CheckBusy();    // 
    SPI_NSS_LOW();
	spi_rw(RADIO_READ_REGISTER);
	spi_rw(addr_h);//MSB
	spi_rw(addr_l);//LSB
    spi_rw(0xFF);
	for( i = 0; i < size; i++ )
    {
		*(buffer+i) = spi_rw(0xFF);
    }
	
    SPI_NSS_HIGH();
    CheckBusy();
}

void SX1280::WriteRegister( uint16_t address, uint8_t value )
{
    WriteRegisters( address, &value, 1 );
}

void SX1280::WriteRegisters( uint16_t address, uint8_t *buffer, uint16_t size )
{// ********** page 74 datasheet **********
	
/*	
    Cette fonction sert à écrire un bloc d'octets dans un espace mémoire de données à partir d'une adresse spécifique. 
	L'adresse est automatiquement incrémenté après chaque octet de données afin que les données soient stockées 
	dans des emplacements de mémoire voisins. 
*/
    uint8_t addr_l,addr_h;
	uint8_t i;
	
	addr_l = address&0xff;
	addr_h = address>>8;

    CheckBusy();
    SPI_NSS_LOW();
	
	spi_rw(RADIO_WRITE_REGISTER); //Opcode 0x18
	spi_rw(addr_h);//MSB
	spi_rw(addr_l);//LSB
	for(i=0;i<size;i++)
	{
		spi_rw(buffer[i]);
	}
	
    SPI_NSS_HIGH();
    CheckBusy();
}


int32_t SX1280::GetLoRaBandwidth(void)
{
    int32_t bwValue = 0;

    switch( lora_para_pt->band_width )
    {
        case LORA_BW_0200:
            bwValue = 203125;
            break;
        case LORA_BW_0400:
            bwValue = 406250;
            break;
        case LORA_BW_0800:
            bwValue = 812500;
            break;
        case LORA_BW_1600:
            bwValue = 1625000;
            break;
        default:
            bwValue = 0;
    }
    return bwValue;
}



double SX1280::GetFrequencyError(void)
{
    uint8_t efeRaw[3] = {0};
    uint32_t efe = 0;
    double efeHz = 0.0;

	efeRaw[0] = ReadRegister( REG_LR_ESTIMATED_FREQUENCY_ERROR_MSB );
	efeRaw[1] = ReadRegister( REG_LR_ESTIMATED_FREQUENCY_ERROR_MSB + 1 );
	efeRaw[2] = ReadRegister( REG_LR_ESTIMATED_FREQUENCY_ERROR_MSB + 2 );
	efe = ( efeRaw[0]<<16 ) | ( efeRaw[1]<<8 ) | efeRaw[2];
	efe &= REG_LR_ESTIMATED_FREQUENCY_ERROR_MASK;

	efeHz = 1.55 * ( double )complement2( efe, 20 ) / ( 1600.0 / ( double )GetLoRaBandwidth( ) * 1000.0 );


    return efeHz;
}

void SX1280::SetRangingIdLength( RadioRangingIdCheckLengths_t length )
{

            WriteRegister( REG_LR_RANGINGIDCHECKLENGTH, ( ( ( ( uint8_t )length ) & 0x03 ) << 6 ) | ( ReadRegister( REG_LR_RANGINGIDCHECKLENGTH ) & 0x3F ) );

}

void SX1280::SetDeviceRangingAddress( uint32_t address )
{
    uint8_t addrArray[] = { address >> 24, address >> 16, address >> 8, address };

            WriteRegisters( REG_LR_DEVICERANGINGADDR, addrArray, 4 );

}

void SX1280::SetRangingRequestAddress( uint32_t address )
{
    uint8_t addrArray[] = { address >> 24, address >> 16, address >> 8, address };

            WriteRegisters( REG_LR_REQUESTRANGINGADDR, addrArray, 4 );

}

double SX1280::GetRangingResult( uint8_t resultType )
{
    uint32_t valLsb = 0;
    double val = 0.0;

    switch( GetPacketType() )
    {
        case PACKET_TYPE_RANGING:
            SetStandby( STDBY_XOSC );
            WriteRegister( 0x97F,ReadRegister( 0x97F ) | ( 1 << 1 ) ); // enable LORA modem clock
            WriteRegister( REG_LR_RANGINGRESULTCONFIG, ( ReadRegister( REG_LR_RANGINGRESULTCONFIG ) & MASK_RANGINGMUXSEL ) | ( ( ( ( uint8_t )resultType ) & 0x03 ) << 4 ) );
            valLsb = ( ( ReadRegister( REG_LR_RANGINGRESULTBASEADDR ) << 16 ) | ( ReadRegister( REG_LR_RANGINGRESULTBASEADDR + 1 ) << 8 ) | ( ReadRegister( REG_LR_RANGINGRESULTBASEADDR + 2 ) ) );
            SetStandby( STDBY_RC );

            // Convertion from LSB to distance. For explanation on the formula, refer to Datasheet of SX1280

                    // Convert the ranging LSB to distance in meter
                    // The theoretical conversion from register value to distance [m] is given by:
                    // distance [m] = ( complement2( register ) * 150 ) / ( 2^12 * bandwidth[MHz] ) )
                    // The API provide BW in [Hz] so the implemented formula is complement2( register ) / bandwidth[Hz] * A,
                    // where A = 150 / (2^12 / 1e6) = 36621.09
                    val = ( double )complement2( valLsb, 24 ) / ( double )GetLoRaBandwidth( ) * 36621.09375;
                    //val = ( double )valLsb * 20.0 / 100.0;

                    //val = 0.0;

					/*val += Sx1280RangingCorrection::GetRangingCorrectionPerSfBwGain(
                    lora_para_pt->lora_sf,
                    lora_para_pt->band_width,
                    GetRangingPowerDeltaThresholdIndicator( )
                );
*/
    }
    return val;
}

uint8_t SX1280::GetRangingPowerDeltaThresholdIndicator( void )
{
    SetStandby( STDBY_XOSC );
    WriteRegister( 0x97F, ReadRegister( 0x97F ) | ( 1 << 1 ) ); // enable LoRa modem clock
    WriteRegister( REG_LR_RANGINGRESULTCONFIG, ( ReadRegister( REG_LR_RANGINGRESULTCONFIG ) & MASK_RANGINGMUXSEL ) | ( ( ( ( uint8_t )RANGING_RESULT_RAW ) & 0x03 ) << 4 ) ); // Select raw results
    
	return ReadRegister( REG_RANGING_RSSI );
}

void SX1280::SetRangingCalibration( uint16_t cal )
{
 
            WriteRegister( REG_LR_RANGINGRERXTXDELAYCAL, ( uint8_t )( ( cal >> 8 ) & 0xFF ) );
            WriteRegister( REG_LR_RANGINGRERXTXDELAYCAL + 1, ( uint8_t )( ( cal ) & 0xFF ) );
 
}

void SX1280::RangingClearFilterResult( void )
{
    uint8_t regVal = ReadRegister( REG_LR_RANGINGRESULTCLEARREG );

    // To clear result, set bit 5 to 1 then to 0
    WriteRegister( REG_LR_RANGINGRESULTCLEARREG, regVal | ( 1 << 5 ) );
    WriteRegister( REG_LR_RANGINGRESULTCLEARREG, regVal & ( ~( 1 << 5 ) ) );
}

void SX1280::RangingSetFilterNumSamples( uint8_t num )
{
    // Silently set 8 as minimum value
    WriteRegister( REG_LR_RANGINGFILTERWINDOWSIZE, ( num < DEFAULT_RANGING_FILTER_SIZE ) ? DEFAULT_RANGING_FILTER_SIZE : num );
}

void SX1280::SetRangingRole( uint8_t role )
{
    uint8_t buf[1];

    buf[0] = role;
    WriteCommand( RADIO_SET_RANGING_ROLE, &buf[0], 1 );
}



/*void OnRangingDone( IrqRangingCode_t val )
{
    if( val == IRQ_RANGING_MASTER_VALID_CODE || val == IRQ_RANGING_SLAVE_VALID_CODE )
    {
        DemoInternalState = APP_RANGING_DONE;
    }
    else if( val == IRQ_RANGING_MASTER_ERROR_CODE || val == IRQ_RANGING_SLAVE_ERROR_CODE )
    {
        DemoInternalState = APP_RANGING_TIMEOUT;
    }
    else
    {
        DemoInternalState = APP_RANGING_TIMEOUT;
    }
}

*/

void SX1280::EnableManualGain( void )
{
    WriteRegister( REG_ENABLE_MANUAL_GAIN_CONTROL,ReadRegister( REG_ENABLE_MANUAL_GAIN_CONTROL ) | MASK_MANUAL_GAIN_CONTROL );
	WriteRegister( REG_DEMOD_DETECTION, ReadRegister( REG_DEMOD_DETECTION ) & MASK_DEMOD_DETECTION );
}

void SX1280::DisableManualGain( void )
{
    WriteRegister( REG_ENABLE_MANUAL_GAIN_CONTROL, ReadRegister( REG_ENABLE_MANUAL_GAIN_CONTROL ) & (~MASK_MANUAL_GAIN_CONTROL) );
    WriteRegister( REG_DEMOD_DETECTION, ReadRegister( REG_DEMOD_DETECTION ) | (~MASK_DEMOD_DETECTION) );
}

void SX1280::SetManualGainValue( uint8_t gain )
{
    this->WriteRegister( REG_MANUAL_GAIN_VALUE, ( this->ReadRegister( REG_MANUAL_GAIN_VALUE ) & MASK_MANUAL_GAIN_VALUE ) | gain );
}

void SX1280::SetLNAGainSetting( const RadioLnaSettings_t lnaSetting )
{
    switch(lnaSetting)
    {
        case LNA_HIGH_SENSITIVITY_MODE:
        {
            WriteRegister( REG_LNA_REGIME, ReadRegister( REG_LNA_REGIME ) | MASK_LNA_REGIME );
            break;
        }
        case LNA_LOW_POWER_MODE:
        {
            WriteRegister( REG_LNA_REGIME, ReadRegister( REG_LNA_REGIME ) & ~MASK_LNA_REGIME );
            break;
        }
    }
}

/*void SX1280::ProcessIrqs( void )
{
    RadioPacketTypes_t packetType = PACKET_TYPE_NONE;

    if( this->PollingMode == true )
    {
        if( this->IrqState == true )
        {
            __disable_irq( );
            this->IrqState = false;
            __enable_irq( );
        }
        else
        {
            return;
        }
    }

    packetType = GetPacketType( true );
    uint16_t irqRegs = GetIrqStatus( );
    ClearIrqStatus( IRQ_RADIO_ALL );


            switch( OperatingMode )
            {
                // MODE_RX indicates an IRQ on the Slave side
                case MODE_RX:
                    if( ( irqRegs & IRQ_RANGING_SLAVE_REQUEST_DISCARDED ) == IRQ_RANGING_SLAVE_REQUEST_DISCARDED )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_SLAVE_ERROR_CODE );
                        }
                    }
                    if( ( irqRegs & IRQ_RANGING_SLAVE_REQUEST_VALID ) == IRQ_RANGING_SLAVE_REQUEST_VALID )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_SLAVE_VALID_CODE );
                        }
                    }
                    if( ( irqRegs & IRQ_RANGING_SLAVE_RESPONSE_DONE ) == IRQ_RANGING_SLAVE_RESPONSE_DONE )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_SLAVE_VALID_CODE );
                        }
                    }
                    if( ( irqRegs & IRQ_RX_TX_TIMEOUT ) == IRQ_RX_TX_TIMEOUT )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_SLAVE_ERROR_CODE );
                        }
                    }
                    if( ( irqRegs & IRQ_HEADER_VALID ) == IRQ_HEADER_VALID )
                    {
                        if( rxHeaderDone != NULL )
                        {
                            rxHeaderDone( );
                        }
                    }
                    if( ( irqRegs & IRQ_HEADER_ERROR ) == IRQ_HEADER_ERROR )
                    {
                        if( rxError != NULL )
                        {
                            rxError( IRQ_HEADER_ERROR_CODE );
                        }
                    }
                    break;
                // MODE_TX indicates an IRQ on the Master side
                case MODE_TX:
                    if( ( irqRegs & IRQ_RANGING_MASTER_TIMEOUT ) == IRQ_RANGING_MASTER_TIMEOUT )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_MASTER_ERROR_CODE );
                        }
                    }
                    if( ( irqRegs & IRQ_RANGING_MASTER_RESULT_VALID ) == IRQ_RANGING_MASTER_RESULT_VALID )
                    {
                        if( rangingDone != NULL )
                        {
                            rangingDone( IRQ_RANGING_MASTER_VALID_CODE );
                        }
                    }
                    break;
                default:
                    // Unexpected IRQ: silently returns
                    break;
            }

    
}
*/
int32_t SX1280::complement2( const uint32_t num, const uint8_t bitCnt )
{
    int32_t retVal = ( int32_t )num;
    if( num >= 2<<( bitCnt - 2 ) )
    {
        retVal -= 2<<( bitCnt - 1 );
    }
    return retVal;
}




/*uint8_t RunDemoApplicationRanging( void )
{
    uint8_t refreshDisplay = 0;

    if( Eeprom.EepromData.DemoSettings.HoldDemo == true )
    {
        return 0;   // quit without refresh display
    }

    if( DemoRunning == false )
    {
        DemoRunning = true;
        TX_LED = 0;
        RX_LED = 0;
        ANT_SW = 1;

#ifdef PRINT_DEBUG
        printf( "Start RunDemoApplicationRanging\r\n" );
#endif

        Eeprom.EepromData.DemoSettings.CntPacketTx = 0;
        Eeprom.EepromData.DemoSettings.RngFei      = 0.0;
        Eeprom.EepromData.DemoSettings.RngStatus   = RNG_INIT;
        InitializeDemoParameters( Eeprom.EepromData.DemoSettings.ModulationType );

        if( Eeprom.EepromData.DemoSettings.Entity == MASTER )
        {
            Eeprom.EepromData.DemoSettings.TimeOnAir = RX_TX_INTER_PACKET_DELAY;
            Radio.SetDioIrqParams( IRQ_RX_DONE | IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT | IRQ_RANGING_MASTER_RESULT_VALID | IRQ_RANGING_MASTER_TIMEOUT,
                                   IRQ_RX_DONE | IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT | IRQ_RANGING_MASTER_RESULT_VALID | IRQ_RANGING_MASTER_TIMEOUT,
                                   IRQ_RADIO_NONE, IRQ_RADIO_NONE );
            Eeprom.EepromData.DemoSettings.RngDistance = 0.0;
            DemoInternalState = APP_RANGING_CONFIG;
        }
        else
        {
            Radio.SetDioIrqParams( IRQ_RADIO_ALL, IRQ_RADIO_ALL, IRQ_RADIO_NONE, IRQ_RADIO_NONE );
            DemoInternalState = APP_RANGING_CONFIG;
        }
    }

    Radio.ProcessIrqs( );

    if( Eeprom.EepromData.DemoSettings.Entity == MASTER )
    {
        switch( DemoInternalState )
        {
            case APP_RANGING_CONFIG:
                if( Eeprom.EepromData.DemoSettings.HoldDemo == false )
                {
                    Eeprom.EepromData.DemoSettings.RngStatus = RNG_INIT;
                    Eeprom.EepromData.DemoSettings.CntPacketTx++;
                    ModulationParams.PacketType = PACKET_TYPE_LORA;
                    PacketParams.PacketType     = PACKET_TYPE_LORA;
                    memcpy( &( ModulationParams.Params.LoRa.SpreadingFactor ), Eeprom.Buffer + MOD_RNG_SPREADF_EEPROM_ADDR,      1 );
                    memcpy( &( ModulationParams.Params.LoRa.Bandwidth ),       Eeprom.Buffer + MOD_RNG_BW_EEPROM_ADDR,           1 );
                    memcpy( &( ModulationParams.Params.LoRa.CodingRate ),      Eeprom.Buffer + MOD_RNG_CODERATE_EEPROM_ADDR,     1 );
                    memcpy( &( PacketParams.Params.LoRa.PreambleLength ),      Eeprom.Buffer + PAK_RNG_PREAMBLE_LEN_EEPROM_ADDR, 1 );
                    memcpy( &( PacketParams.Params.LoRa.HeaderType ),          Eeprom.Buffer + PAK_RNG_HEADERTYPE_EEPROM_ADDR,   1 );
                    PacketParams.Params.LoRa.PayloadLength = 7;
                    memcpy( &( PacketParams.Params.LoRa.Crc ),                 Eeprom.Buffer + PAK_RNG_CRC_MODE_EEPROM_ADDR,     1 );
                    memcpy( &( PacketParams.Params.LoRa.InvertIQ ),            Eeprom.Buffer + PAK_RNG_IQ_INV_EEPROM_ADDR,       1 );
                    Radio.SetPacketType( ModulationParams.PacketType );
                    Radio.SetModulationParams( &ModulationParams );
                    Radio.SetPacketParams( &PacketParams );
                    Radio.SetRfFrequency( Eeprom.EepromData.DemoSettings.Frequency );
                    Eeprom.EepromData.DemoSettings.CntPacketRxOK = 0;
                    Eeprom.EepromData.DemoSettings.CntPacketRxOKSlave = 0;
                    MeasuredChannels  = 0;
                    CurrentChannel    = 0;
                    Buffer[0] = ( Eeprom.EepromData.DemoSettings.RngAddress >> 24 ) & 0xFF;
                    Buffer[1] = ( Eeprom.EepromData.DemoSettings.RngAddress >> 16 ) & 0xFF;
                    Buffer[2] = ( Eeprom.EepromData.DemoSettings.RngAddress >>  8 ) & 0xFF;
                    Buffer[3] = ( Eeprom.EepromData.DemoSettings.RngAddress & 0xFF );
                    Buffer[4] = CurrentChannel;    // set the first channel to use
                    Buffer[5] = Eeprom.EepromData.DemoSettings.RngAntenna;      // set the antenna strategy
                    Buffer[6] = Eeprom.EepromData.DemoSettings.RngRequestCount; // set the number of hops
                    TX_LED = 1;
                    Radio.SendPayload( Buffer, PacketParams.Params.LoRa.PayloadLength, ( TickTime_t ){ RX_TIMEOUT_TICK_SIZE, RNG_COM_TIMEOUT } );
                    DemoInternalState = APP_IDLE;
                }
                break;

            case APP_RNG:
                if( SendNext == true )
                {
                    SendNext = false;
                    MeasuredChannels++;
                    if( MeasuredChannels <= Eeprom.EepromData.DemoSettings.RngRequestCount )
                    {
                        Radio.SetRfFrequency( Channels[CurrentChannel] );
                        TX_LED = 1;
                        CurrentChannel++;
                        if( CurrentChannel >= CHANNELS )
                        {
                            CurrentChannel -= CHANNELS;
                        }
                        switch( Eeprom.EepromData.DemoSettings.RngAntenna )
                        {
                            case DEMO_RNG_ANT_1:
                                //ANT_SW = 1; // ANT1
                                Eeprom.EepromData.DemoSettings.AntennaSwitch = 0;
                                break;

                            case DEMO_RNG_ANT_0:
                                //ANT_SW = 0; // ANT0
                                Eeprom.EepromData.DemoSettings.AntennaSwitch = 1;
                                break;

                            case DEMO_RNG_ANT_BOTH:
                                if( ANT_SW == 1 )
                                {
                                    //ANT_SW = 0;
                                    Eeprom.EepromData.DemoSettings.AntennaSwitch = 1;
                                }
                                else
                                {
                                    //ANT_SW = 1;
                                    Eeprom.EepromData.DemoSettings.AntennaSwitch = 0;
                                }
                                break;
                        }
                        SetAntennaSwitch( );
                        DemoInternalState = APP_IDLE;
                        Radio.SetTx( ( TickTime_t ){ RADIO_TICK_SIZE_1000_US, 0xFFFF } );
                    }
                    else
                    {
                        Eeprom.EepromData.DemoSettings.CntPacketRxOKSlave = CheckDistance( );
                        refreshDisplay = 1;
                        SendNextPacket.detach( );
                        Eeprom.EepromData.DemoSettings.HoldDemo = true;
                        SendNext = false;
                        DemoInternalState = APP_RANGING_CONFIG;
                        Eeprom.EepromData.DemoSettings.RngStatus = RNG_INIT;
                    }
                }
                break;

            case APP_RANGING_DONE:
                TX_LED = 0;
                RawRngResults[RngResultIndex] = Radio.GetRangingResult( RANGING_RESULT_RAW );
                RawRngResults[RngResultIndex] += Sx1280RangingCorrection::GetRangingCorrectionPerSfBwGain(
                    ModulationParams.Params.LoRa.SpreadingFactor,
                    ModulationParams.Params.LoRa.Bandwidth,
                    Radio.GetRangingPowerDeltaThresholdIndicator( )
                );
                RngResultIndex++;

                Eeprom.EepromData.DemoSettings.CntPacketRxOK++;
                DemoInternalState = APP_RNG;
                break;

            case APP_RANGING_TIMEOUT:
                TX_LED = 0;
                DemoInternalState = APP_RNG;
                break;

            case APP_RX:
                RX_LED = 0;
                if( Eeprom.EepromData.DemoSettings.RngStatus == RNG_INIT )
                {
                    Radio.GetPayload( Buffer, &BufferSize, BUFFER_SIZE );
                    if( BufferSize > 0 )
                    {
                        Eeprom.EepromData.DemoSettings.RxTimeOutCount = 0;
                        Eeprom.EepromData.DemoSettings.RngStatus = RNG_PROCESS;
                        Eeprom.EepromData.DemoSettings.RngFei = ( double )( ( ( int32_t )Buffer[4] << 24 ) | \
                                                                            ( ( int32_t )Buffer[5] << 16 ) | \
                                                                            ( ( int32_t )Buffer[6] <<  8 ) | \
                                                                                         Buffer[7] );
                        Eeprom.EepromData.DemoSettings.RssiValue = Buffer[8]; // for ranging post-traitment (since V3 only)
                        ModulationParams.PacketType = PACKET_TYPE_RANGING;
                        PacketParams.PacketType     = PACKET_TYPE_RANGING;

                        memcpy( &( ModulationParams.Params.LoRa.SpreadingFactor ), Eeprom.Buffer + MOD_RNG_SPREADF_EEPROM_ADDR,      1 );
                        memcpy( &( ModulationParams.Params.LoRa.Bandwidth ),       Eeprom.Buffer + MOD_RNG_BW_EEPROM_ADDR,           1 );
                        memcpy( &( ModulationParams.Params.LoRa.CodingRate ),      Eeprom.Buffer + MOD_RNG_CODERATE_EEPROM_ADDR,     1 );
                        memcpy( &( PacketParams.Params.LoRa.PreambleLength ),      Eeprom.Buffer + PAK_RNG_PREAMBLE_LEN_EEPROM_ADDR, 1 );
                        memcpy( &( PacketParams.Params.LoRa.HeaderType ),          Eeprom.Buffer + PAK_RNG_HEADERTYPE_EEPROM_ADDR,   1 );
                        PacketParams.Params.LoRa.PayloadLength = 10;
                        memcpy( &( PacketParams.Params.LoRa.Crc ),                 Eeprom.Buffer + PAK_RNG_CRC_MODE_EEPROM_ADDR,     1 );
                        memcpy( &( PacketParams.Params.LoRa.InvertIQ ),            Eeprom.Buffer + PAK_RNG_IQ_INV_EEPROM_ADDR,       1 );

                        Radio.SetPacketType( ModulationParams.PacketType );
                        Radio.SetModulationParams( &ModulationParams );
                        Radio.SetPacketParams( &PacketParams );
                        Radio.SetRangingRequestAddress( Eeprom.EepromData.DemoSettings.RngAddress );
                        Radio.SetRangingCalibration( Eeprom.EepromData.DemoSettings.RngCalib );
                        Radio.SetTxParams( Eeprom.EepromData.DemoSettings.TxPower, RADIO_RAMP_20_US );

                        MeasuredChannels = 0;
                        RngResultIndex   = 0;
                        SendNextPacket.attach_us( &SendNextPacketEvent, Eeprom.EepromData.DemoSettings.RngReqDelay * 1000 );
                        DemoInternalState = APP_RNG;
                    }
                    else
                    {
                        DemoInternalState = APP_RANGING_CONFIG;
                    }
                }
                else
                {
                    DemoInternalState = APP_RANGING_CONFIG;
                }
                break;

            case APP_TX:
                TX_LED = 0;
                if( Eeprom.EepromData.DemoSettings.RngStatus == RNG_INIT )
                {
                    RX_LED = 1;
                    Radio.SetRx( ( TickTime_t ) { RX_TIMEOUT_TICK_SIZE, RNG_COM_TIMEOUT } );
                    DemoInternalState = APP_IDLE;
                }
                else
                {
                    DemoInternalState = APP_RANGING_CONFIG;
                }
                break;

            case APP_RX_TIMEOUT:
                RX_LED = 0;
                Eeprom.EepromData.DemoSettings.RngStatus = RNG_TIMEOUT;
                DemoInternalState = APP_RANGING_CONFIG;
                Eeprom.EepromData.DemoSettings.HoldDemo = true;
                refreshDisplay = 1; // display error on token color (RNG_TIMEOUT)
                break;

            case APP_RX_ERROR:
                RX_LED = 0;
                DemoInternalState = APP_RANGING_CONFIG;
                Eeprom.EepromData.DemoSettings.HoldDemo = true;
                refreshDisplay = 1; // display error on token color (RNG_TIMEOUT)
                break;

            case APP_TX_TIMEOUT:
                TX_LED = 0;
                DemoInternalState = APP_RANGING_CONFIG;
                Eeprom.EepromData.DemoSettings.HoldDemo = true;
                refreshDisplay = 1; // display error on token color (RNG_TIMEOUT)
                break;

            case APP_IDLE: // do nothing
                break;

            default:
                DemoInternalState = APP_RANGING_CONFIG;
                Eeprom.EepromData.DemoSettings.HoldDemo = true;
                break;
        }
    }
    else    // Slave
    {
        switch( DemoInternalState )
        {
            case APP_RANGING_CONFIG:
                Eeprom.EepromData.DemoSettings.RngStatus = RNG_INIT;
                ModulationParams.PacketType = PACKET_TYPE_LORA;
                PacketParams.PacketType     = PACKET_TYPE_LORA;
                memcpy( &( ModulationParams.Params.LoRa.SpreadingFactor ), Eeprom.Buffer + MOD_RNG_SPREADF_EEPROM_ADDR,      1 );
                memcpy( &( ModulationParams.Params.LoRa.Bandwidth ),       Eeprom.Buffer + MOD_RNG_BW_EEPROM_ADDR,           1 );
                memcpy( &( ModulationParams.Params.LoRa.CodingRate ),      Eeprom.Buffer + MOD_RNG_CODERATE_EEPROM_ADDR,     1 );
                memcpy( &( PacketParams.Params.LoRa.PreambleLength ),      Eeprom.Buffer + PAK_RNG_PREAMBLE_LEN_EEPROM_ADDR, 1 );
                memcpy( &( PacketParams.Params.LoRa.HeaderType ),          Eeprom.Buffer + PAK_RNG_HEADERTYPE_EEPROM_ADDR,   1 );
                PacketParams.Params.LoRa.PayloadLength = 9;
                memcpy( &( PacketParams.Params.LoRa.Crc ),                 Eeprom.Buffer + PAK_RNG_CRC_MODE_EEPROM_ADDR,     1 );
                memcpy( &( PacketParams.Params.LoRa.InvertIQ ),            Eeprom.Buffer + PAK_RNG_IQ_INV_EEPROM_ADDR,       1 );
                Radio.SetPacketType( ModulationParams.PacketType );
                Radio.SetModulationParams( &ModulationParams );
                Radio.SetPacketParams( &PacketParams );
                Radio.SetRfFrequency( Eeprom.EepromData.DemoSettings.Frequency );
                RX_LED = 1;
                // use listen mode here instead of rx continuous
                Radio.SetRx( ( TickTime_t ) { RADIO_TICK_SIZE_1000_US, 0xFFFF } );
                DemoInternalState = APP_IDLE;
                break;

            case APP_RNG:
                if( SendNext == true )
                {
                    SendNext = false;
                    MeasuredChannels++;
                    if( MeasuredChannels <= Eeprom.EepromData.DemoSettings.RngRequestCount )
                    {
                        Radio.SetRfFrequency( Channels[CurrentChannel] );
                        RX_LED = 1;
                        CurrentChannel++;
                        if( CurrentChannel >= CHANNELS )
                        {
                            CurrentChannel -= CHANNELS;
                        }
                        switch( Eeprom.EepromData.DemoSettings.RngAntenna )
                        {
                            case DEMO_RNG_ANT_1:
                                //ANT_SW = 1; // ANT1
                                Eeprom.EepromData.DemoSettings.AntennaSwitch = 0;
                                break;

                            case DEMO_RNG_ANT_0:
                                //ANT_SW = 0; // ANT0
                                Eeprom.EepromData.DemoSettings.AntennaSwitch = 1;
                                break;

                            case DEMO_RNG_ANT_BOTH:
                                if( ANT_SW == 1 )
                                {
                                    //ANT_SW = 0;
                                    Eeprom.EepromData.DemoSettings.AntennaSwitch = 1;
                                }
                                else
                                {
                                    //ANT_SW = 1;
                                    Eeprom.EepromData.DemoSettings.AntennaSwitch = 0;
                                }
                                break;
                        }
                        SetAntennaSwitch( );
                        DemoInternalState = APP_IDLE;
                        Radio.SetRx( ( TickTime_t ){ RADIO_TICK_SIZE_1000_US, Eeprom.EepromData.DemoSettings.RngReqDelay } );
                    }
                    else
                    {
                        Radio.SetStandby( STDBY_RC );
                        refreshDisplay = 1;
                        SendNextPacket.detach( );
                        Eeprom.EepromData.DemoSettings.RngStatus = RNG_VALID;
                        DemoInternalState = APP_RANGING_CONFIG;
                    }
                }
                break;

            case APP_RANGING_DONE:
                RX_LED = 0;
                Eeprom.EepromData.DemoSettings.CntPacketRxOK++;
                DemoInternalState = APP_RNG;
                break;

            case APP_RANGING_TIMEOUT:
                RX_LED = 0;
                DemoInternalState = APP_RNG;
                break;

            case APP_RX:
                RX_LED = 0;
                if( Eeprom.EepromData.DemoSettings.RngStatus == RNG_INIT )
                {
                    Radio.GetPayload( Buffer, &BufferSize, BUFFER_SIZE );
                    Radio.GetPacketStatus( &PacketStatus );
                    if( ( BufferSize > 0 ) && \
                        ( Buffer[0] == ( ( Eeprom.EepromData.DemoSettings.RngAddress >> 24 ) & 0xFF ) ) && \
                        ( Buffer[1] == ( ( Eeprom.EepromData.DemoSettings.RngAddress >> 16 ) & 0xFF ) ) && \
                        ( Buffer[2] == ( ( Eeprom.EepromData.DemoSettings.RngAddress >>  8 ) & 0xFF ) ) && \
                        ( Buffer[3] == (   Eeprom.EepromData.DemoSettings.RngAddress         & 0xFF ) ) )
                    {
                        Eeprom.EepromData.DemoSettings.RngFei    = Radio.GetFrequencyError( );
                        Eeprom.EepromData.DemoSettings.RssiValue = PacketStatus.LoRa.RssiPkt;
                        Eeprom.EepromData.DemoSettings.CntPacketTx++;
                        CurrentChannel                                 = Buffer[4];
                        // The slave does not get its antenna configuration from Master, that is the reason why next line is commented out so Buffer[5] is not read
                        // Eeprom.EepromData.DemoSettings.RngAntenna      = Buffer[5];
                        Eeprom.EepromData.DemoSettings.RngRequestCount = Buffer[6];
                        wait_us( 10 );
                        Buffer[4] = ( ( ( int32_t )Eeprom.EepromData.DemoSettings.RngFei ) >> 24 ) & 0xFF ;
                        Buffer[5] = ( ( ( int32_t )Eeprom.EepromData.DemoSettings.RngFei ) >> 16 ) & 0xFF ;
                        Buffer[6] = ( ( ( int32_t )Eeprom.EepromData.DemoSettings.RngFei ) >>  8 ) & 0xFF ;
                        Buffer[7] = ( ( ( int32_t )Eeprom.EepromData.DemoSettings.RngFei ) & 0xFF );
                        Buffer[8] = Eeprom.EepromData.DemoSettings.RssiValue;
                        TX_LED = 1;
                        Radio.SendPayload( Buffer, 9, ( TickTime_t ){ RADIO_TICK_SIZE_1000_US, RNG_COM_TIMEOUT } );
                        DemoInternalState = APP_IDLE;
                    }
                    else
                    {
                        DemoInternalState = APP_RANGING_CONFIG;
                    }
                }
                else
                {
                    DemoInternalState = APP_RANGING_CONFIG;
                }
                break;

            case APP_TX:
                TX_LED = 0;
                if( Eeprom.EepromData.DemoSettings.RngStatus == RNG_INIT )
                {
                    Eeprom.EepromData.DemoSettings.RngStatus = RNG_PROCESS;

                    ModulationParams.PacketType = PACKET_TYPE_RANGING;
                    PacketParams.PacketType     = PACKET_TYPE_RANGING;

                    memcpy( &( ModulationParams.Params.LoRa.SpreadingFactor ), Eeprom.Buffer + MOD_RNG_SPREADF_EEPROM_ADDR,      1 );
                    memcpy( &( ModulationParams.Params.LoRa.Bandwidth ),       Eeprom.Buffer + MOD_RNG_BW_EEPROM_ADDR,           1 );
                    memcpy( &( ModulationParams.Params.LoRa.CodingRate ),      Eeprom.Buffer + MOD_RNG_CODERATE_EEPROM_ADDR,     1 );
                    memcpy( &( PacketParams.Params.LoRa.PreambleLength ),      Eeprom.Buffer + PAK_RNG_PREAMBLE_LEN_EEPROM_ADDR, 1 );
                    memcpy( &( PacketParams.Params.LoRa.HeaderType ),          Eeprom.Buffer + PAK_RNG_HEADERTYPE_EEPROM_ADDR,   1 );
                    PacketParams.Params.LoRa.PayloadLength = 10;
                    memcpy( &( PacketParams.Params.LoRa.Crc ),                 Eeprom.Buffer + PAK_RNG_CRC_MODE_EEPROM_ADDR,     1 );
                    memcpy( &( PacketParams.Params.LoRa.InvertIQ ),            Eeprom.Buffer + PAK_RNG_IQ_INV_EEPROM_ADDR,       1 );

                    Radio.SetPacketType( ModulationParams.PacketType );

                    Radio.SetModulationParams( &ModulationParams );
                    Radio.SetPacketParams( &PacketParams );
                    Radio.SetDeviceRangingAddress( Eeprom.EepromData.DemoSettings.RngAddress );
                    Radio.SetRangingCalibration( Eeprom.EepromData.DemoSettings.RngCalib );
                    Radio.SetTxParams( Eeprom.EepromData.DemoSettings.TxPower, RADIO_RAMP_20_US );
                    Eeprom.EepromData.DemoSettings.CntPacketRxOK = 0;
                    MeasuredChannels = 0;
                    Eeprom.EepromData.DemoSettings.CntPacketRxKOSlave = 0;
                    SendNextPacket.attach_us( &SendNextPacketEvent, Eeprom.EepromData.DemoSettings.RngReqDelay * 1000 );
                    DemoInternalState = APP_RNG;
                }
                else
                {
                    DemoInternalState = APP_RANGING_CONFIG;
                }
                break;

            case APP_RX_TIMEOUT:
                RX_LED = 0;
                DemoInternalState = APP_RANGING_CONFIG;
                break;

            case APP_RX_ERROR:
                RX_LED = 0;
                DemoInternalState = APP_RANGING_CONFIG;
                break;

            case APP_TX_TIMEOUT:
                TX_LED = 0;
                DemoInternalState = APP_RANGING_CONFIG;
                break;

            case APP_IDLE: // do nothing
                if( Eeprom.EepromData.DemoSettings.CntPacketRxKOSlave > DEMO_RNG_CHANNELS_COUNT_MAX )
                {
                    Eeprom.EepromData.DemoSettings.CntPacketRxKOSlave = 0;
                    refreshDisplay = 1;
                    RX_LED = 0;
                    DemoInternalState = APP_RANGING_CONFIG;
                    SendNextPacket.detach( );
                }
                break;

            default:
                DemoInternalState = APP_RANGING_CONFIG;
                SendNextPacket.detach( );
                break;
        }
    }
    return refreshDisplay;
}


*/












// ************************************* PAS UTILE *************************************


/*

void SX1280::SetSaveContext( void )
{
    WriteCommand( RADIO_SET_SAVECONTEXT, 0, 0 );
}

void SX1280::SetSleep(void)
{	
		// ************** page 77 **************
/*
Cette fonction est utilisée pour mettre le Module LORA en mode sleep avec la consommation de courant la plus faible possible.
à l'aide de la commande SetSleep() qui a pour Opcode 0x84
Après la mise à 1 de NSS, tous les blocs sont désactivés sauf le régulateur de secours si nécessaire et les blocs spécifiés dans sleepConfig
paramètre.
*/
/*
	uint8_t Opcode,sleepConfig;
	
	Opcode = 0x84;
	sleepConfig = 0x07;	//bit2: 1: ; bit0: 0: 
	
	CheckBusy();     // On Verifie que le module LORA ne fait rien
	SPI_NSS_LOW();   // Mise à l' ETAT BAS de l'esclave pour débuter la transmission SPI
	spi_rw(Opcode);
	spi_rw(sleepConfig);
	SPI_NSS_HIGH();
}


void SX1280::SetRxDutyCycle(uint8_t PeriodBase, uint16_t NbStepRx, uint16_t RxNbStepSleep )
{
	uint8_t buf[5];

    buf[0] = PeriodBase;
    buf[1] = ( uint8_t )( ( NbStepRx >> 8 ) & 0x00FF );
    buf[2] = ( uint8_t )( NbStepRx & 0x00FF );
    buf[3] = ( uint8_t )( ( RxNbStepSleep >> 8 ) & 0x00FF );
    buf[4] = ( uint8_t )( RxNbStepSleep & 0x00FF );
	
	WriteCommand( RADIO_SET_RXDUTYCYCLE, buf, 5 );
}


void SX1280::SetCadParams( uint8_t cadSymbolNum )
{
    WriteCommand( RADIO_SET_CADPARAMS,&cadSymbolNum, 1 );
}
void SX1280::SetLongPreamble( uint8_t enable )
{
    WriteCommand( RADIO_SET_LONGPREAMBLE, &enable, 1 );
}

void SX1280::SetCad( void )
{
    WriteCommand( RADIO_SET_CAD, 0, 0 );
}
void SX1280::SetTxContinuousWave( void )
{
    WriteCommand( RADIO_SET_TXCONTINUOUSWAVE, 0, 0 );
}
void SX1280::SetTxContinuousPreamble( void )
{
    WriteCommand( RADIO_SET_TXCONTINUOUSPREAMBLE, 0, 0 );
}

// ************************************* -------- *************************************


*/